# AsaBedWars 3.0.0
BedWars gaya Hypixel untuk PaperMC (Java + Bedrock via Geyser/Floodgate).
Dikompilasi terhadap Paper API 1.21.11 (bytecode Java 21) -> jalan di 1.21.11 s/d 26.x, Java 21 maupun 25.

## Build
    mvn clean package                 # hasil: target/AsaBedWars-3.0.0.jar  -> taruh di plugins/
    mvn clean package -Ppaper-26      # build khusus Paper 26.x (Java 25)

## Alur pemain (baru)
    /bw join  -> GUI "Select Gamemode" (Solo / Duo / Squad)
              -> pindah ke WaitingLobby mode itu (world terpisah), inventory di-reset
              -> hotbar: slot 5 = Vote Map (PAPER), slot 9 = Quit (RED_BED)
              -> hitung mundur -> map dengan vote terbanyak dimainkan -> scoreboard berganti ke in-game
              -> game selesai: auto reset inventory/status -> kembali ke lobby utama
(`/bw arenas` sudah dihapus; diganti `/bw join`.)

## Daftar file
Ditambahkan : AsaBedWars (main, ganti BedWarsPlugin), LobbyManager, WaitingRoom, QueueManager, ModeMenu, VoteMenu,
              LobbyListener, BoardService, Cooldowns
Dimodifikasi: Game (pemain datang dari antrean, auto reset), GameListener, BWCommand, Arena, ArenaManager,
              Items, Msg, ShopGUI, UpgradeGUI, config.yml, plugin.yml, pom.xml
Dihapus     : BedWarsPlugin, ArenaMenu (digantikan ModeMenu + VoteMenu)
Tidak berubah: Mode, BWTeam, TeamUpgrades, BedrockUtil, SidebarBoard

## Command pemain (bedwars.play)
| Command | Fungsi |
|---|---|
| /bw join | Buka GUI Select Gamemode |
| /bw join <solo/duo/squad> | Langsung masuk antrean mode itu |
| /bw leave | Keluar dari antrean / game |
| /bw lobby | Teleport ke lobby BedWars sendiri (/bw setmainlobby) |
| /bw stats | Lihat statistikmu (wins, kills, dst) |
| /bw list | Arena aktif per mode + isi waiting lobby |
| /bw help | Bantuan |

## Command admin (bedwars.admin)
| Command | Fungsi |
|---|---|
| /bw setwaiting <mode> <1-3> | Set WaitingHub (3 hub per mode) di posisimu |
| /bw delwaiting <mode> <1-3> | Hapus hub |
| /bw setmainlobby | Lobby utama (tujuan setelah game / Quit) |
| /bw lobbies | Cek semua waiting lobby & lobby utama |
| /bw create <nama> / edit <nama> / delete <nama> | Kelola arena |
| /bw setmode <solo/duo/squad/1v1> | Mode arena (menentukan di Vote Map mana ia muncul) |
| /bw setmin <n> | Minimal pemain arena |
| /bw setspec | Titik spectator |
| /bw setspawn <tim> / setbed <tim> | Spawn & bed tim (lihat bed) |
| /bw addgen <diamond/emerald> | Generator tengah |
| /bw addshop / addupgrade / clearshops | NPC Item Shop / Upgrade Tim |
| /bw info / enable / disable | Cek, aktifkan, nonaktifkan arena |
| /bw reload | Muat ulang config, lobbies.yml, arena |
Permission `bedwars.bypass` + Creative = boleh build/break di world arena & waiting lobby (untuk admin yang membangun map).

## Contoh konfigurasi
### config.yml (potongan)
    waiting:
      world-names:
        SOLO: waitingBwSolo
        DUO: waitingBwDuo
        SQUAD: waitingBwSquad
      enforce-world-names: true
    queue:
      min-players: 2
      full-countdown: 5
    exit:
      restore-inventory: false     # false = inventory di-reset total
      gamemode: SURVIVAL

### lobbies.yml (dibuat otomatis oleh /bw setwaiting & /bw setmainlobby, boleh diedit manual)
    main-lobby: {world: world, x: 0.5, y: 100.0, z: 0.5, yaw: 0.0, pitch: 0.0}
    hubs:
      SOLO:
        1: {world: waitingBwSolo, x: 0.5,   y: 80.0, z: 0.5, yaw: 0.0, pitch: 0.0}
        2: {world: waitingBwSolo, x: 100.5, y: 80.0, z: 0.5, yaw: 0.0, pitch: 0.0}
        3: {world: waitingBwSolo, x: 200.5, y: 80.0, z: 0.5, yaw: 0.0, pitch: 0.0}
      DUO:
        1: {world: waitingBwDuo, x: 0.5, y: 80.0, z: 0.5, yaw: 0.0, pitch: 0.0}
      SQUAD:
        1: {world: waitingBwSquad, x: 0.5, y: 80.0, z: 0.5, yaw: 0.0, pitch: 0.0}

### arenas.yml (potongan; mode menentukan arena muncul di Vote Map mana)
    arenas:
      Sky_Fortress: {mode: SOLO, min: 2, enabled: true, ...}
      Twin_Towers:  {mode: DUO,  min: 2, enabled: true, ...}

## Setup WaitingLobby (per mode)
1. Buat world terpisah dari arena (mis. lewat Multiverse): waitingBwSolo, waitingBwDuo, waitingBwSquad.
2. Bangun lobby-nya. Hub 1-3 bisa di titik berbeda dalam world yang sama (tiap hub = antrean & vote sendiri).
3. Berdiri di spawn hub:  /bw setwaiting solo 1   (ulangi 2 dan 3 bila perlu; juga duo / squad)
4. Di lobby utama server:  /bw setmainlobby
5. Cek: /bw lobbies

## Lobby BedWars sendiri (terpisah dari hub server)
Set `/bw setmainlobby` di world khusus BedWars (mis. bwLobby). Setelah game / Quit, pemain kembali ke sana, bukan ke hub server.
Scoreboard BedWars hanya ada selama pemain di waiting lobby atau game, dan dihapus saat keluar.
Pemain bisa ke lobby ini kapan saja dengan /bw lobby.

## Tiga scoreboard (terpisah)
| Scoreboard | Muncul saat | Diatur di |
|---|---|---|
| Lobby BedWars | di lobby BW (tidak di antrean/game), hanya di world tertentu | config `lobby-scoreboard` |
| Waiting | menunggu pemain di waiting lobby | config `scoreboard.title-waiting` |
| In-game | pertandingan berjalan | config `scoreboard.title-ingame` |
World lobby scoreboard: daftar `lobby-scoreboard.worlds` dan/atau world `/bw setmainlobby` (`use-main-lobby-world`).
Placeholder lobby: {name} {wins} {kills} {finalkills} {deaths} {beds} {games} {kdr} {online} {domain}.
Statistik disimpan di `stats.yml` (autosave 5 menit + saat server stop). Pemain bisa cek lewat `/bw stats`.
Scoreboard lobby hanya mereset board miliknya sendiri, jadi tidak menimpa scoreboard plugin lain (mis. AsaLobbyCore).

## Setup arena
1. /bw create Sky_Fortress  ->  /bw setmode solo
2. /bw setspec ; /bw setspawn red ; /bw setbed red ; ... (minimal 2 tim)
3. /bw addshop ; /bw addupgrade ; /bw addgen diamond ; /bw addgen emerald ; /bw setmin 2
4. /bw info -> /bw enable
Arena harus di SATU world dan TIDAK boleh di world WaitingLobby (ditolak otomatis).

## Sistem Vote Map
- GUI hanya menampilkan arena yang enabled + mode-nya sama dengan antrean pemain.
- 1 pemain = 1 vote aktif; boleh ganti sebelum game mulai; klik map yang sama tidak menggandakan.
- Jumlah vote diperbarui tiap detik dan seketika saat ada yang vote.
- Pemenang = vote terbanyak; seri atau tanpa vote = acak di antara kandidat. Map yang sedang dipakai / tidak muat
  jumlah pemain otomatis dilewati.
- Anti spam: cooldown klik; vote hanya untuk antrean sendiri.

## Proteksi block
- Di world arena yang enabled dan world waiting lobby, blok bawaan map tidak bisa dihancurkan/dipasang
  (juga bucket, api, ledakan) oleh pemain di luar game.
- Di dalam game: yang boleh hancur hanya (1) bed musuh lewat mekanisme BedWars dan (2) blok buatan pemain.
- Data blok buatan pemain dicatat terpisah per game dan di-reset saat arena selesai.

## Auto reset inventory (akhir game / keluar)
Inventory, armor, offhand, efek potion, health, food, XP, api, fall distance direset lalu pemain dikembalikan ke
lobby utama. Set `exit.restore-inventory: true` bila ingin isi inventory sebelum join dikembalikan.

## Catatan
- Plugin ini bernama AsaBedWars: folder data baru plugins/AsaBedWars/. arenas.yml lama dari plugins/BedWars/ otomatis disalin.
  Titik "waiting" lama di arenas.yml diabaikan; set ulang lewat /bw setwaiting.
- Multiverse: lokasi disimpan sebagai nama world dan di-resolve saat dipakai. Multiverse-Inventories didukung lewat jeda
  setelah pindah world (multiverse.inventory-delay-ticks).
- Geyser/Floodgate: semua UI = chest GUI dan item biasa.
