package id.bedwars;

import org.bukkit.Location;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Arena {
    public final String name;
    public Location spectator;
    public Mode mode = Mode.SOLO;
    public int minPlayers = 2;
    public boolean enabled = false;
    public final Map<BWTeam, Location> spawns = new EnumMap<>(BWTeam.class);
    public final Map<BWTeam, Location> beds = new EnumMap<>(BWTeam.class);
    public final List<Location> diamondGens = new ArrayList<>();
    public final List<Location> emeraldGens = new ArrayList<>();
    public final List<Location> shops = new ArrayList<>();
    public final List<Location> upgradeShops = new ArrayList<>();

    public Arena(String name) { this.name = name; }

    public String mapName() { return name.replace('_', ' ').replace('-', ' '); }

    /** Nama world utama arena (dari spectator / spawn), null jika belum diset. */
    public String worldName() {
        if (spectator != null && spectator.getWorld() != null) return spectator.getWorld().getName();
        for (Location l : spawns.values()) if (l.getWorld() != null) return l.getWorld().getName();
        return null;
    }

    /** Semua world yang dipakai titik-titik arena. */
    public Set<String> worldNames() {
        Set<String> s = new HashSet<>();
        add(s, spectator);
        spawns.values().forEach(l -> add(s, l));
        beds.values().forEach(l -> add(s, l));
        diamondGens.forEach(l -> add(s, l));
        emeraldGens.forEach(l -> add(s, l));
        shops.forEach(l -> add(s, l));
        upgradeShops.forEach(l -> add(s, l));
        return s;
    }

    private static void add(Set<String> s, Location l) {
        if (l != null && l.getWorld() != null) s.add(l.getWorld().getName());
    }

    /** Tim yang punya spawn + bed. */
    public List<BWTeam> activeTeams() {
        List<BWTeam> l = new ArrayList<>();
        for (BWTeam t : BWTeam.values()) if (spawns.containsKey(t) && beds.containsKey(t)) l.add(t);
        return l;
    }

    /** Tim yang dipakai sesuai mode (mis. 1v1 hanya 2 tim pertama). */
    public List<BWTeam> usedTeams() {
        List<BWTeam> a = activeTeams();
        return a.size() > mode.maxTeams ? new ArrayList<>(a.subList(0, mode.maxTeams)) : a;
    }

    public int maxPlayers() { return usedTeams().size() * mode.teamSize; }

    /** null jika arena siap dipakai, selain itu alasan kenapa belum siap. */
    public String validate() {
        if (spectator == null || spectator.getWorld() == null) return "Spectator belum diset / dunianya belum dimuat (/bw setspec).";
        if (usedTeams().size() < 2) return "Minimal 2 tim dengan spawn + bed (/bw setspawn, /bw setbed).";
        if (shops.isEmpty()) return "Belum ada shop (/bw addshop).";
        if (minPlayers > maxPlayers()) return "Min pemain (" + minPlayers + ") lebih besar dari kapasitas (" + maxPlayers() + ").";
        if (worldNames().size() > 1) return "Semua titik arena harus berada di SATU world (sekarang: " + worldNames() + ").";
        return null;
    }
}
