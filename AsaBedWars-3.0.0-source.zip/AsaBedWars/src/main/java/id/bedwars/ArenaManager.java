package id.bedwars;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ArenaManager {
    private final AsaBedWars plugin;
    private final File file;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();
    private final Map<String, Game> games = new HashMap<>();
    private final Map<UUID, Game> byPlayer = new ConcurrentHashMap<>();
    private boolean readOnly;
    private boolean missing;

    public ArenaManager(AsaBedWars plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "arenas.yml");
    }

    // ---------- registry ----------
    public Arena get(String name) { return name == null ? null : arenas.get(name.toLowerCase()); }
    public Collection<Arena> all() { return arenas.values(); }
    public Game game(Arena a) { return games.get(a.name.toLowerCase()); }
    public Game gameFor(Arena a) { return games.computeIfAbsent(a.name.toLowerCase(), k -> new Game(plugin, this, a)); }
    public Game gameOf(Player p) { return byPlayer.get(p.getUniqueId()); }
    public void bind(UUID id, Game g) { byPlayer.put(id, g); }
    public void unbind(UUID id) { byPlayer.remove(id); }
    public boolean isReadOnly() { return readOnly; }

    /** Arena yang sudah enabled, valid, dan bermode tertentu (dipakai Vote Map). */
    public List<Arena> arenasFor(Mode mode) {
        List<Arena> l = new ArrayList<>();
        for (Arena a : arenas.values()) {
            if (a.enabled && a.mode == mode && a.validate() == null) l.add(a);
        }
        return l;
    }

    public List<Game> runningGames() {
        List<Game> l = new ArrayList<>();
        for (Game g : games.values()) if (g.getState() == Game.State.RUNNING) l.add(g);
        return l;
    }

    /** true jika world dipakai arena yang di-enable atau WaitingLobby (dilindungi dari build/break). */
    public boolean isProtectedWorld(World w) {
        if (w == null) return false;
        String n = w.getName();
        if (plugin.lobby().isLobbyWorld(n)) return true;
        for (Arena a : arenas.values()) {
            if (a.enabled && n.equals(a.worldName())) return true;
        }
        return false;
    }

    /** true jika world dipakai titik arena mana pun (enabled maupun tidak). */
    public boolean isArenaWorld(String worldName) {
        for (Arena a : arenas.values()) if (a.worldNames().contains(worldName)) return true;
        return false;
    }

    public Arena create(String name) {
        Arena a = new Arena(name);
        arenas.put(name.toLowerCase(), a);
        save();
        return a;
    }

    /** false jika masih ada pemain di dalam. */
    public boolean release(Arena a) {
        Game g = games.get(a.name.toLowerCase());
        if (g != null && !g.isIdle()) return false;
        games.remove(a.name.toLowerCase());
        return true;
    }

    public boolean delete(Arena a) {
        if (!release(a)) return false;
        arenas.remove(a.name.toLowerCase());
        save();
        return true;
    }

    public void shutdown() {
        for (Game g : new ArrayList<>(games.values())) g.forceStop();
        games.clear();
        byPlayer.clear();
    }

    public void reload() {
        shutdown();
        load();
    }

    // ---------- persistence ----------
    public void load() {
        arenas.clear();
        readOnly = false;
        missing = false;
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("arenas");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            Arena a = new Arena(key);
            // key "waiting"/"lobby" dari versi lama diabaikan: WaitingLobby kini dikelola lobbies.yml
            a.spectator = loc(s, "spectator");
            Mode m = Mode.parse(s.getString("mode", "solo"));
            a.mode = m == null ? Mode.SOLO : m;
            a.minPlayers = s.getInt("min", 2);
            a.enabled = s.getBoolean("enabled", false);
            ConfigurationSection ts = s.getConfigurationSection("teams");
            if (ts != null) {
                for (String tk : ts.getKeys(false)) {
                    BWTeam t = BWTeam.parse(tk);
                    if (t == null) continue;
                    Location sp = loc(ts, tk + ".spawn");
                    Location bd = loc(ts, tk + ".bed");
                    if (sp != null) a.spawns.put(t, sp);
                    if (bd != null) a.beds.put(t, bd);
                }
            }
            readLocs(s, "diamond", a.diamondGens);
            readLocs(s, "emerald", a.emeraldGens);
            readLocs(s, "shops", a.shops);
            readLocs(s, "upgrade-shops", a.upgradeShops);
            arenas.put(key.toLowerCase(), a);
        }
        if (missing) {
            readOnly = true;
            plugin.getLogger().warning("Sebagian dunia arena belum dimuat (Multiverse?). Arena dikunci (read-only) agar data tidak hilang. "
                    + "Muat dunianya lalu jalankan /bw reload.");
        }
    }

    private Location loc(ConfigurationSection s, String path) {
        if (!s.contains(path)) return null;
        Location l = s.getLocation(path);
        if (l == null) missing = true;
        return l;
    }

    private void readLocs(ConfigurationSection s, String path, List<Location> out) {
        List<?> raw = s.getList(path);
        if (raw == null) return;
        for (Object o : raw) {
            if (o instanceof Location l) out.add(l); else missing = true;
        }
    }

    public void save() {
        if (readOnly) {
            plugin.getLogger().warning("Penyimpanan dilewati: arena dalam mode read-only (dunia belum dimuat).");
            return;
        }
        YamlConfiguration y = new YamlConfiguration();
        for (Arena a : arenas.values()) {
            String b = "arenas." + a.name + ".";
            y.set(b + "spectator", a.spectator);
            y.set(b + "mode", a.mode.name());
            y.set(b + "min", a.minPlayers);
            y.set(b + "enabled", a.enabled);
            for (Map.Entry<BWTeam, Location> e : a.spawns.entrySet())
                y.set(b + "teams." + e.getKey().name() + ".spawn", e.getValue());
            for (Map.Entry<BWTeam, Location> e : a.beds.entrySet())
                y.set(b + "teams." + e.getKey().name() + ".bed", e.getValue());
            y.set(b + "diamond", new ArrayList<>(a.diamondGens));
            y.set(b + "emerald", new ArrayList<>(a.emeraldGens));
            y.set(b + "shops", new ArrayList<>(a.shops));
            y.set(b + "upgrade-shops", new ArrayList<>(a.upgradeShops));
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Gagal menyimpan arenas.yml: " + ex.getMessage());
        }
    }
}
