package id.bedwars;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class AsaBedWars extends JavaPlugin implements Listener {
    public NamespacedKey itemKey;
    public NamespacedKey shopKey;
    private ArenaManager arenas;
    private LobbyManager lobby;
    private QueueManager queues;
    private BoardService boards;
    private StatsManager stats;
    private LobbyBoard lobbyBoard;
    private Cooldowns cooldowns;
    private boolean loaded;

    @Override
    public void onEnable() {
        migrateOldData();
        saveDefaultConfig();
        itemKey = new NamespacedKey(this, "lobby_item");
        shopKey = new NamespacedKey(this, "shop");
        BedrockUtil.init(getConfig().getString("bedrock-prefix", "."));

        cooldowns = new Cooldowns();
        boards = new BoardService(this);
        lobby = new LobbyManager(this);
        arenas = new ArenaManager(this);
        queues = new QueueManager(this);
        stats = new StatsManager(this);
        lobbyBoard = new LobbyBoard(this);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new GameListener(this), this);
        getServer().getPluginManager().registerEvents(new LobbyListener(this), this);

        // Arena & lobby dimuat setelah semua dunia (termasuk dunia Multiverse) siap.
        getServer().getScheduler().runTask(this, this::loadOnce);

        PluginCommand cmd = getCommand("bw");
        if (cmd != null) {
            BWCommand h = new BWCommand(this);
            cmd.setExecutor(h);
            cmd.setTabCompleter(h);
        }
        getLogger().info("AsaBedWars " + getPluginMeta().getVersion() + " aktif. Floodgate: " + yn("floodgate")
                + " | Multiverse-Core: " + yn("Multiverse-Core")
                + " | Multiverse-Inventories: " + yn("Multiverse-Inventories"));
    }

    private String yn(String plugin) { return getServer().getPluginManager().isPluginEnabled(plugin) ? "ya" : "tidak"; }

    /** Salin arenas.yml dari plugins/BedWars (versi lama) jika data baru belum ada. */
    private void migrateOldData() {
        File data = getDataFolder();
        File oldArenas = new File(new File(data.getParentFile(), "BedWars"), "arenas.yml");
        File newArenas = new File(data, "arenas.yml");
        if (oldArenas.exists() && !newArenas.exists()) {
            try {
                data.mkdirs();
                Files.copy(oldArenas.toPath(), newArenas.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
                getLogger().info("arenas.yml lama dimigrasi dari plugins/BedWars/.");
            } catch (IOException ex) {
                getLogger().warning("Gagal migrasi arenas.yml lama: " + ex.getMessage());
            }
        }
    }

    @EventHandler
    public void onServerLoad(ServerLoadEvent e) { loadOnce(); }

    private void loadOnce() {
        if (loaded) return;
        loaded = true;
        lobby.load();
        arenas.load();
        stats.load();
        stats.start();
        lobbyBoard.start();
        getLogger().info(arenas.all().size() + " arena dimuat.");
    }

    @Override
    public void onDisable() {
        if (lobbyBoard != null) lobbyBoard.shutdown();
        if (queues != null) queues.shutdown();
        if (arenas != null) {
            arenas.shutdown();
            arenas.save();
        }
        if (stats != null) stats.shutdown();
    }

    public ArenaManager arenas() { return arenas; }
    public LobbyManager lobby() { return lobby; }
    public QueueManager queues() { return queues; }
    public BoardService boards() { return boards; }
    public Cooldowns cooldowns() { return cooldowns; }
    public StatsManager stats() { return stats; }
    public LobbyBoard lobbyBoard() { return lobbyBoard; }

    public boolean mvInventories() {
        return getServer().getPluginManager().isPluginEnabled("Multiverse-Inventories");
    }

    /**
     * Teleport pemain lalu jalankan aksi. Jika pindah dunia dan Multiverse-Inventories aktif,
     * aksi (atur inventory/gamemode) ditunda beberapa tick agar tidak ditimpa MV-Inventories.
     */
    public void teleportThen(Player p, Location dest, Runnable after) {
        World before = p.getWorld();
        p.teleport(dest);
        boolean crossWorld = dest.getWorld() != null && !before.equals(dest.getWorld());
        if (crossWorld && mvInventories() && isEnabled()) {
            long delay = Math.max(1, getConfig().getInt("multiverse.inventory-delay-ticks", 3));
            getServer().getScheduler().runTaskLater(this, after, delay);
        } else {
            after.run();
        }
    }
}
