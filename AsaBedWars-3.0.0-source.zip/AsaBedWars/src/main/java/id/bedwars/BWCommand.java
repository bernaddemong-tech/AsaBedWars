package id.bedwars;

import org.bukkit.Location;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class BWCommand implements CommandExecutor, TabCompleter {
    private final AsaBedWars plugin;
    private final ArenaManager mgr;
    private final Map<UUID, String> editing = new HashMap<>();

    private static final List<String> PLAYER_SUBS = List.of("join", "leave", "list", "lobby", "stats", "help");
    private static final List<String> ADMIN_SUBS = List.of("create", "edit", "delete", "setmode", "setmin", "setspec",
            "setspawn", "setbed", "addgen", "addshop", "addupgrade", "clearshops", "enable", "disable", "info", "reload",
            "setwaiting", "delwaiting", "setmainlobby", "lobbies");
    private static final Set<String> LOBBY_SUBS = Set.of("setwaiting", "delwaiting", "setmainlobby", "lobbies");
    private static final Set<String> ARENA_POINT_SUBS = Set.of("setspec", "setspawn", "setbed", "addgen", "addshop", "addupgrade");

    public BWCommand(AsaBedWars plugin) {
        this.plugin = plugin;
        this.mgr = plugin.arenas();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Perintah ini hanya untuk pemain."); return true; }
        if (a.length == 0) { help(p); return true; }
        switch (a[0].toLowerCase()) {
            case "join" -> join(p, a);
            case "leave" -> {
                Game g = mgr.gameOf(p);
                if (g != null) g.leave(p);
                else if (!plugin.queues().leave(p, false)) Msg.send(p, "&cKamu tidak sedang di antrean atau game.");
            }
            case "list" -> list(p);
            case "lobby" -> lobby(p);
            case "stats" -> {
                StatsManager.Stats st = plugin.stats().peek(p.getUniqueId());
                Msg.send(p, "&6Statistik &f" + p.getName());
                p.sendMessage(Msg.c(" &7Wins: &f" + st.wins + " &7- Games: &f" + st.games));
                p.sendMessage(Msg.c(" &7Kills: &f" + st.kills + " &7- Final kills: &f" + st.finalKills
                        + " &7- Deaths: &f" + st.deaths + " &7- K/D: &f" + st.kdr()));
                p.sendMessage(Msg.c(" &7Beds dihancurkan: &f" + st.beds));
            }
            case "help" -> help(p);
            default -> admin(p, a);
        }
        return true;
    }

    private void join(Player p, String[] a) {
        if (mgr.gameOf(p) != null) { Msg.send(p, "&cKamu sedang berada di dalam game."); return; }
        if (plugin.queues().roomOf(p) != null) { Msg.send(p, "&cKamu sudah di antrean. Gunakan item Keluar atau /bw leave."); return; }
        if (a.length >= 2) {
            Mode m = Mode.parse(a[1]);
            if (m == null) { Msg.send(p, "&cGunakan: /bw join atau /bw join <solo/duo/squad>"); return; }
            plugin.queues().join(p, m);
            return;
        }
        ModeMenu.open(p, plugin);   // GUI Select Gamemode
    }

    /** Teleport ke lobby BedWars sendiri (/bw setmainlobby), hanya jika tidak sedang di antrean/game. */
    private void lobby(Player p) {
        if (mgr.gameOf(p) != null || plugin.queues().roomOf(p) != null) {
            Msg.send(p, "&cKeluar dulu dari antrean/game (/bw leave).");
            return;
        }
        Location l = plugin.lobby().mainLocation();
        if (l == null) { Msg.send(p, "&cLobby BedWars belum diset atau world-nya belum dimuat."); return; }
        p.teleport(l);
        Msg.send(p, "&aKamu berada di lobby BedWars.");
    }

    private void list(Player p) {
        Msg.send(p, "&eArena aktif:");
        for (Mode m : Mode.values()) {
            List<Arena> l = mgr.arenasFor(m);
            if (l.isEmpty()) continue;
            StringBuilder sb = new StringBuilder();
            for (Arena ar : l) {
                Game g = mgr.game(ar);
                boolean busy = g != null && !g.isIdle();
                if (sb.length() > 0) sb.append("&7, ");
                sb.append(busy ? "&c" : "&a").append(ar.mapName());
            }
            p.sendMessage(Msg.c(" &6" + m.display + "&7: " + sb));
        }
        Msg.send(p, "&eWaiting lobby:");
        for (WaitingRoom r : plugin.queues().allRooms()) {
            if (r.size() == 0) continue;
            p.sendMessage(Msg.c(" &6" + r.mode.display + " #" + r.hub + " &7- &f" + r.size() + "/" + r.capacity()
                    + " &8(" + r.state() + ")"));
        }
    }

    private void help(Player p) {
        Msg.send(p, "&e/bw join &7- pilih gamemode (GUI)  &e/bw join <solo/duo/squad>  &e/bw leave  &e/bw lobby  &e/bw stats  &e/bw list");
        if (p.hasPermission("bedwars.admin")) {
            Msg.send(p, "&6Lobby: &7setwaiting <mode> <1-3>, delwaiting <mode> <1-3>, setmainlobby, lobbies");
            Msg.send(p, "&6Arena: &7create, edit, delete, setmode <solo/duo/squad/1v1>, setmin, setspec,");
            Msg.send(p, "&7setspawn <tim>, setbed <tim> (lihat bed), addgen <diamond/emerald>,");
            Msg.send(p, "&7addshop, addupgrade, clearshops, enable, disable, info, reload");
            Msg.send(p, "&7Tim: " + String.join(", ", Arrays.stream(BWTeam.values()).map(t -> t.name().toLowerCase()).toList()));
        }
    }

    private Arena selected(Player p) {
        String n = editing.get(p.getUniqueId());
        Arena a = n == null ? null : mgr.get(n);
        if (a == null) Msg.send(p, "&cPilih arena dulu: /bw create <nama> atau /bw edit <nama>");
        return a;
    }

    // ---------- admin: lobby ----------
    private void lobbyAdmin(Player p, String sub, String[] a) {
        LobbyManager lobby = plugin.lobby();
        switch (sub) {
            case "setwaiting" -> {
                Mode m = a.length < 2 ? null : Mode.parse(a[1]);
                Integer idx = parse(a, 2);
                if (m == null || idx == null || idx < 1 || idx > LobbyManager.MAX_HUBS) {
                    Msg.send(p, "&cGunakan: /bw setwaiting <solo/duo/squad/1v1> <1-" + LobbyManager.MAX_HUBS + ">");
                    return;
                }
                String problem = lobby.checkWaitingWorld(m, p.getWorld());
                if (problem != null) { Msg.send(p, "&c" + problem); return; }
                lobby.setHub(m, idx, p.getLocation());
                Msg.send(p, "&aWaitingLobby &e" + m.display + " #" + idx + " &adiset di world &f" + p.getWorld().getName() + "&a.");
            }
            case "delwaiting" -> {
                Mode m = a.length < 2 ? null : Mode.parse(a[1]);
                Integer idx = parse(a, 2);
                if (m == null || idx == null) { Msg.send(p, "&cGunakan: /bw delwaiting <mode> <1-" + LobbyManager.MAX_HUBS + ">"); return; }
                WaitingRoom busy = null;
                for (WaitingRoom r : plugin.queues().allRooms()) if (r.mode == m && r.hub == idx && r.size() > 0) busy = r;
                if (busy != null) { Msg.send(p, "&cMasih ada pemain di hub itu."); return; }
                Msg.send(p, lobby.removeHub(m, idx) ? "&aHub dihapus." : "&cHub tidak ditemukan.");
            }
            case "setmainlobby" -> {
                String w = p.getWorld().getName();
                if (lobby.isLobbyWorld(w) || mgr.isArenaWorld(w)) {
                    Msg.send(p, "&cLobby utama tidak boleh di world arena / waiting lobby.");
                    return;
                }
                lobby.setMain(p.getLocation());
                Msg.send(p, "&aLobby utama diset. Pemain kembali ke sini setelah game / keluar antrean.");
            }
            case "lobbies" -> {
                for (Mode m : Mode.values()) {
                    List<Integer> idx = lobby.hubIndexes(m);
                    String cfg = lobby.configuredWorld(m);
                    StringBuilder sb = new StringBuilder();
                    for (int i : idx) {
                        LobbyManager.Spot sp = lobby.hubSpot(m, i);
                        boolean ok = lobby.hubLocation(m, i) != null;
                        sb.append(" &f#").append(i).append(ok ? " &a" : " &c(world belum dimuat) ").append(sp.world());
                    }
                    Msg.send(p, "&6" + m.display + " &7(config world: &f" + (cfg == null ? "-" : cfg) + "&7):"
                            + (idx.isEmpty() ? " &cbelum ada hub" : sb.toString()));
                }
                LobbyManager.Spot ms = lobby.mainSpot();
                Msg.send(p, "&6Lobby utama: " + (ms == null ? "&cbelum diset (pemain dikembalikan ke lokasi asal)"
                        : "&a" + ms.world() + " " + (lobby.mainLocation() == null ? "&c(world belum dimuat)" : "")));
            }
            default -> { }
        }
    }

    // ---------- admin ----------
    private void admin(Player p, String[] a) {
        if (!p.hasPermission("bedwars.admin")) { Msg.send(p, "&cKamu tidak punya izin. /bw help"); return; }
        String sub = a[0].toLowerCase();

        if (sub.equals("reload")) {
            plugin.reloadConfig();
            plugin.lobby().load();
            mgr.reload();
            Msg.send(p, "&aKonfigurasi, lobby & arena dimuat ulang." + (mgr.isReadOnly() ? " &c(masih ada dunia yang belum dimuat)" : ""));
            return;
        }
        if (LOBBY_SUBS.contains(sub)) { lobbyAdmin(p, sub, a); return; }
        if (mgr.isReadOnly() && !sub.equals("info")) {
            Msg.send(p, "&cAda dunia arena yang belum dimuat (Multiverse?). Muat dunianya lalu /bw reload.");
            return;
        }

        switch (sub) {
            case "create" -> {
                if (a.length < 2 || !a[1].matches("[A-Za-z0-9_-]{1,24}")) { Msg.send(p, "&cGunakan: /bw create <nama> (huruf/angka/_/-)"); return; }
                if (mgr.get(a[1]) != null) { Msg.send(p, "&cArena sudah ada."); return; }
                Arena ar = mgr.create(a[1]);
                editing.put(p.getUniqueId(), ar.name);
                Msg.send(p, "&aArena &e" + ar.name + " &adibuat dan dipilih untuk diedit.");
                return;
            }
            case "edit" -> {
                Arena ar = a.length < 2 ? null : mgr.get(a[1]);
                if (ar == null) { Msg.send(p, "&cArena tidak ditemukan."); return; }
                editing.put(p.getUniqueId(), ar.name);
                Msg.send(p, "&aMengedit arena &e" + ar.name);
                return;
            }
            case "delete" -> {
                Arena ar = a.length < 2 ? null : mgr.get(a[1]);
                if (ar == null) { Msg.send(p, "&cArena tidak ditemukan."); return; }
                if (!mgr.delete(ar)) Msg.send(p, "&cMasih ada pemain di arena itu."); else Msg.send(p, "&aArena dihapus.");
                return;
            }
            default -> { }
        }

        Arena ar = selected(p);
        if (ar == null) return;

        switch (sub) {
            case "info" -> {
                Msg.send(p, "&eArena &f" + ar.name + " &7(" + (ar.enabled ? "&aaktif" : "&cnonaktif") + "&7)");
                Msg.send(p, "&7Mode: &f" + ar.mode.display + " &7- Kapasitas: &f" + ar.maxPlayers() + " &7- Min: &f" + ar.minPlayers
                        + " &7- World: &f" + ar.worldNames());
                Msg.send(p, "&7Spec: " + (ar.spectator != null) + " - Tim siap: " + ar.activeTeams() + " - Shop: " + ar.shops.size()
                        + " - Upgrade NPC: " + ar.upgradeShops.size()
                        + " - Diamond: " + ar.diamondGens.size() + " - Emerald: " + ar.emeraldGens.size());
                String v = ar.validate();
                Msg.send(p, v == null ? "&aArena siap diaktifkan (/bw enable)." : "&cBelum siap: " + v);
                return;
            }
            case "enable" -> {
                String v = ar.validate();
                if (v != null) { Msg.send(p, "&c" + v); return; }
                for (String w : ar.worldNames()) {
                    if (plugin.lobby().isLobbyWorld(w)) {
                        Msg.send(p, "&cArena berada di world WaitingLobby (" + w + "). Gunakan world terpisah.");
                        return;
                    }
                }
                if (plugin.lobby().hubIndexes(ar.mode).isEmpty()) {
                    Msg.send(p, "&eCatatan: WaitingLobby mode " + ar.mode.display + " belum diset (/bw setwaiting " + ar.mode.name().toLowerCase() + " 1).");
                }
                ar.enabled = true;
                mgr.save();
                Msg.send(p, "&aArena diaktifkan! Muncul di Vote Map mode " + ar.mode.display + ".");
                return;
            }
            case "disable" -> {
                if (!mgr.release(ar)) { Msg.send(p, "&cMasih ada pemain di arena itu."); return; }
                ar.enabled = false;
                mgr.save();
                Msg.send(p, "&eArena dinonaktifkan.");
                return;
            }
            default -> { }
        }

        if (ar.enabled) { Msg.send(p, "&cNonaktifkan arena dulu (/bw disable) sebelum mengedit."); return; }
        if (ARENA_POINT_SUBS.contains(sub) && plugin.lobby().isLobbyWorld(p.getWorld().getName())) {
            Msg.send(p, "&cWorld ini adalah WaitingLobby. Titik arena harus di world terpisah.");
            return;
        }
        Location here = p.getLocation();

        switch (sub) {
            case "setspec" -> { ar.spectator = here; Msg.send(p, "&aSpectator diset."); }
            case "setmode" -> {
                Mode m = a.length < 2 ? null : Mode.parse(a[1]);
                if (m == null) { Msg.send(p, "&cGunakan: /bw setmode <solo/duo/squad/1v1>"); return; }
                ar.mode = m;
                Msg.send(p, "&aMode: &f" + m.display + " &7(" + m.teamSize + " pemain/tim, maks " + m.maxTeams
                        + " tim, kapasitas arena " + ar.maxPlayers() + ")");
            }
            case "setmin" -> {
                Integer n = parse(a, 1);
                if (n == null || n < 2) { Msg.send(p, "&cGunakan: /bw setmin <angka>=2"); return; }
                ar.minPlayers = n;
                Msg.send(p, "&aMinimal pemain: " + n);
            }
            case "setspawn" -> {
                BWTeam t = a.length < 2 ? null : BWTeam.parse(a[1]);
                if (t == null) { Msg.send(p, "&cTim tidak valid. /bw help"); return; }
                ar.spawns.put(t, here);
                Msg.send(p, "&aSpawn tim " + t.legacy() + t.display + " &adiset (generator besi/emas juga di titik ini).");
            }
            case "setbed" -> {
                BWTeam t = a.length < 2 ? null : BWTeam.parse(a[1]);
                if (t == null) { Msg.send(p, "&cTim tidak valid. /bw help"); return; }
                Block b = p.getTargetBlockExact(6);
                if (b == null || !Tag.BEDS.isTagged(b.getType())) { Msg.send(p, "&cArahkan crosshair ke bed (jarak <6 blok)."); return; }
                ar.beds.put(t, b.getLocation());
                Msg.send(p, "&aBed tim " + t.legacy() + t.display + " &adiset.");
            }
            case "addgen" -> {
                String type = a.length < 2 ? "" : a[1].toLowerCase();
                if (type.equals("diamond")) ar.diamondGens.add(here);
                else if (type.equals("emerald")) ar.emeraldGens.add(here);
                else { Msg.send(p, "&cGunakan: /bw addgen <diamond/emerald>"); return; }
                Msg.send(p, "&aGenerator " + type + " ditambahkan.");
            }
            case "addshop" -> { ar.shops.add(here); Msg.send(p, "&aItem shop ditambahkan (" + ar.shops.size() + ")."); }
            case "addupgrade" -> { ar.upgradeShops.add(here); Msg.send(p, "&aNPC Upgrade Tim ditambahkan (" + ar.upgradeShops.size() + ")."); }
            case "clearshops" -> { ar.shops.clear(); ar.upgradeShops.clear(); Msg.send(p, "&eSemua NPC shop dihapus."); }
            default -> { Msg.send(p, "&cSub-perintah tidak dikenal. /bw help"); return; }
        }
        mgr.save();
    }

    private Integer parse(String[] a, int i) {
        if (a.length <= i) return null;
        try { return Integer.parseInt(a[i]); } catch (NumberFormatException e) { return null; }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(PLAYER_SUBS);
            if (s.hasPermission("bedwars.admin")) out.addAll(ADMIN_SUBS);
        } else if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "join", "setwaiting", "delwaiting", "setmode" -> out.addAll(List.of("solo", "duo", "squad", "1v1"));
                case "edit", "delete" -> mgr.all().forEach(x -> out.add(x.name));
                case "setspawn", "setbed" -> { for (BWTeam t : BWTeam.values()) out.add(t.name().toLowerCase()); }
                case "addgen" -> out.addAll(List.of("diamond", "emerald"));
                default -> { }
            }
        } else if (a.length == 3 && (a[0].equalsIgnoreCase("setwaiting") || a[0].equalsIgnoreCase("delwaiting"))) {
            out.addAll(List.of("1", "2", "3"));
        }
        String pre = a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(pre));
        return out;
    }
}
