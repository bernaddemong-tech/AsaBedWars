package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Satu-satunya pemilik scoreboard pemain. WaitingRoom dan Game sama-sama merender lewat sini,
 * sehingga scoreboard TIDAK hilang/dibuat ulang saat pemain berpindah state (queue -> game).
 */
public class BoardService {
    private final AsaBedWars plugin;
    private final Map<UUID, SidebarBoard> boards = new HashMap<>();
    private boolean errorLogged, resetLogged;

    public BoardService(AsaBedWars plugin) { this.plugin = plugin; }

    public void render(Player p, String title, List<String> lines, Map<String, BWTeam> names) {
        try {
            UUID id = p.getUniqueId();
            SidebarBoard b = boards.get(id);
            boolean fresh = b == null;
            if (fresh) {
                b = new SidebarBoard(title, plugin.getConfig().getBoolean("scoreboard.hide-numbers", true));
                boards.put(id, b);
            }
            b.title(title);
            b.set(lines);
            if (plugin.getConfig().getBoolean("scoreboard.nametag-colors", true)) b.nameTeams(names);
            if (fresh) {
                p.setScoreboard(b.scoreboard()); // kirim setelah terisi penuh
            } else if (p.getScoreboard() != b.scoreboard()) {
                if (!resetLogged) {
                    resetLogged = true;
                    plugin.getLogger().warning("Scoreboard " + p.getName() + " direset oleh plugin lain; dikembalikan otomatis.");
                }
                p.setScoreboard(b.scoreboard());
            }
        } catch (Throwable ex) {
            if (!errorLogged) {
                errorLogged = true;
                plugin.getLogger().log(Level.SEVERE, "Gagal merender scoreboard untuk " + p.getName(), ex);
            }
        }
    }

    /** Kirim ulang scoreboard penuh (jaga-jaga klien/Geyser membuangnya setelah pindah dunia). */
    public void refresh(Player p) {
        SidebarBoard b = boards.get(p.getUniqueId());
        if (b == null || !p.isOnline()) return;
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        p.setScoreboard(b.scoreboard());
    }

    public void refreshLater(Player p) {
        if (!plugin.isEnabled()) return;
        for (long d : new long[]{20L, 60L, 120L}) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> refresh(p), d);
        }
    }

    public void remove(Player p) {
        removeInternal(p, false);
    }

    /** Reset ke scoreboard utama HANYA jika pemain masih memakai board kita (tidak menimpa plugin lain). */
    public void removeIfOwned(Player p) {
        removeInternal(p, true);
    }

    private void removeInternal(Player p, boolean onlyIfOwned) {
        SidebarBoard b = boards.remove(p.getUniqueId());
        if (!p.isOnline()) return;
        if (onlyIfOwned && (b == null || p.getScoreboard() != b.scoreboard())) return;
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }
}
