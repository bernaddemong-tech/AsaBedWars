package id.bedwars;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Anti-spam klik (GUI, item hotbar, vote). Dibersihkan saat pemain keluar. */
public class Cooldowns {
    private final Map<UUID, Long> last = new HashMap<>();

    /** true jika aksi boleh dijalankan (dan cooldown dimulai ulang). */
    public boolean tryUse(UUID id, long millis) {
        long now = System.currentTimeMillis();
        Long l = last.get(id);
        if (l != null && now - l < millis) return false;
        last.put(id, now);
        return true;
    }

    public void clear(UUID id) { last.remove(id); }
}
