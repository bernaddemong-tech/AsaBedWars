package id.bedwars;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Event untuk pemain yang sedang berada di dalam pertandingan (Game). */
public class GameListener implements Listener {
    private final AsaBedWars plugin;
    private final ArenaManager mgr;
    private final Map<UUID, Long> fireballCooldown = new HashMap<>();

    public GameListener(AsaBedWars plugin) {
        this.plugin = plugin;
        this.mgr = plugin.arenas();
    }

    // ---------- blocks (khusus pemain di dalam game; pemain lain ditangani LobbyListener) ----------
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g == null) return;
        if (g.getState() != Game.State.RUNNING || g.isSpectating(p)) { e.setCancelled(true); return; }
        Block b = e.getBlock();
        if (Tag.BEDS.isTagged(b.getType())) {               // pengecualian 1: bed mengikuti mekanisme BedWars
            e.setDropItems(false);
            if (!g.onBedBreak(p, b)) e.setCancelled(true);
            return;
        }
        if (!g.isPlaced(b)) {                                // blok bawaan map dilindungi
            e.setCancelled(true);
            Msg.send(p, "&cHanya blok buatan pemain yang bisa dihancurkan.");
        } else {                                             // pengecualian 2: blok buatan pemain
            g.removePlaced(b);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g == null) return;
        if (g.getState() != Game.State.RUNNING || g.isSpectating(p)) { e.setCancelled(true); return; }
        Block b = e.getBlock();
        if (b.getType() == Material.TNT) {
            b.setType(Material.AIR);
            Location l = b.getLocation().add(0.5, 0, 0.5);
            b.getWorld().spawn(l, TNTPrimed.class, t -> {
                t.setFuseTicks(40);
                t.setSource(p);
            });
            return;
        }
        g.addPlaced(b);
    }

    /** Ledakan di world arena/lobby: hanya blok buatan pemain yang boleh hancur; kaca tahan ledak. */
    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        World w = e.getLocation().getWorld();
        if (!mgr.isProtectedWorld(w)) return;
        List<Game> running = mgr.runningGames();
        Iterator<Block> it = e.blockList().iterator();
        while (it.hasNext()) {
            Block b = it.next();
            if (b.getType().name().endsWith("GLASS")) { it.remove(); continue; }
            boolean placed = false;
            for (Game g : running) {
                if (g.isPlaced(b)) { g.removePlaced(b); placed = true; break; }
            }
            if (!placed) it.remove();
        }
    }

    // ---------- fireball ----------
    private void launchFireball(Player p, Game g) {
        if (g.getState() != Game.State.RUNNING || g.isSpectating(p)) return;
        long now = System.currentTimeMillis();
        Long last = fireballCooldown.get(p.getUniqueId());
        if (last != null && now - last < 500) return;
        fireballCooldown.put(p.getUniqueId(), now);

        ItemStack hand = p.getInventory().getItemInMainHand();
        hand.setAmount(hand.getAmount() - 1);
        p.getInventory().setItemInMainHand(hand.getAmount() <= 0 ? null : hand);

        Fireball fb = p.launchProjectile(Fireball.class, p.getEyeLocation().getDirection());
        fb.setShooter(p);
        fb.setYield(2.0f);
        fb.setIsIncendiary(false);
    }

    // ---------- damage / death ----------
    private Player attacker(EntityDamageEvent e) {
        if (!(e instanceof EntityDamageByEntityEvent ee)) return null;
        Entity d = ee.getDamager();
        if (d instanceof Player pl) return pl;
        if (d instanceof Projectile pr && pr.getShooter() instanceof Player pl) return pl; // termasuk Fireball
        if (d instanceof TNTPrimed t && t.getSource() instanceof Player pl) return pl;
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Game g = mgr.gameOf(p);
        if (g == null) return;
        boolean isVoid = e.getCause() == EntityDamageEvent.DamageCause.VOID;

        if (g.getState() != Game.State.RUNNING || g.isSpectating(p)) {
            e.setCancelled(true);
            if (isVoid) p.teleport(g.arena.spectator);
            return;
        }
        Player atk = attacker(e);
        if (atk != null && !atk.equals(p)) {
            Game ag = mgr.gameOf(atk);
            if (ag == g) {
                if (g.teamOf(atk) == g.teamOf(p) || g.isSpectating(atk)) { e.setCancelled(true); return; }
                g.recordHit(p, atk);
            }
        }
        // damage ledakan fireball dikurangi (gaya Hypixel)
        if (e.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                && e instanceof EntityDamageByEntityEvent ee && ee.getDamager() instanceof Fireball) {
            e.setDamage(Math.min(e.getDamage(), 3.0));
        }
        if (isVoid || p.getHealth() - e.getFinalDamage() <= 0) {
            e.setCancelled(true);
            g.handleDeath(p, atk);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && mgr.gameOf(p) != null) e.setCancelled(true);
    }

    // ---------- items / interaction ----------
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null || it.getType() != Material.FIRE_CHARGE) return;
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g != null) {
            e.setCancelled(true);
            launchFireball(p, g);
        }
    }

    @EventHandler
    public void onNpc(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Byte kind = e.getRightClicked().getPersistentDataContainer().get(plugin.shopKey, PersistentDataType.BYTE);
        if (kind == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g == null || g.getState() != Game.State.RUNNING || g.isSpectating(p)) return;
        if (kind == 2) UpgradeGUI.open(p, g); else ShopGUI.open(p);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        Game g = mgr.gameOf(e.getPlayer());
        if (g != null && g.getState() != Game.State.RUNNING) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryHolder h = e.getInventory().getHolder();
        boolean top = e.getClickedInventory() != null && e.getClickedInventory().equals(e.getInventory());
        if (h instanceof ShopGUI) {
            e.setCancelled(true);
            Game g = mgr.gameOf(p);
            if (top && g != null && g.getState() == Game.State.RUNNING && !g.isSpectating(p)
                    && plugin.cooldowns().tryUse(p.getUniqueId(), 150)) ShopGUI.buy(p, g, e.getSlot());
            return;
        }
        if (h instanceof UpgradeGUI ug) {
            e.setCancelled(true);
            Game g = mgr.gameOf(p);
            if (top && g != null && g.getState() == Game.State.RUNNING && !g.isSpectating(p)
                    && plugin.cooldowns().tryUse(p.getUniqueId(), 150)) ug.click(p, e.getSlot());
            return;
        }
        if (h instanceof ModeMenu || h instanceof VoteMenu) return;   // ditangani LobbyListener
        Game g = mgr.gameOf(p);
        if (g != null && g.getState() != Game.State.RUNNING) e.setCancelled(true);
    }

    // ---------- chat / commands / quit ----------
    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        WaitingRoom r = plugin.queues().roomOf(p);
        if (g == null && r == null) {
            e.viewers().removeIf(a -> a instanceof Player v && (mgr.gameOf(v) != null || plugin.queues().roomOf(v) != null));
            return;
        }
        if (g != null) {
            e.viewers().removeIf(a -> !(a instanceof Player v) || mgr.gameOf(v) != g);
            BWTeam t = g.teamOf(p);
            if (t == null) return;
            e.renderer(ChatRenderer.viewerUnaware((src, name, msg) ->
                    Msg.c(t.legacy() + "[" + t.display + "] ")
                            .append(Component.text(src.getName(), t.text))
                            .append(Component.text(": ", NamedTextColor.WHITE))
                            .append(msg)));
            return;
        }
        e.viewers().removeIf(a -> !(a instanceof Player v) || plugin.queues().roomOf(v) != r);
        e.renderer(ChatRenderer.viewerUnaware((src, name, msg) ->
                Msg.c("&7[" + r.mode.display + "] &f")
                        .append(Component.text(src.getName(), NamedTextColor.GRAY))
                        .append(Component.text(": ", NamedTextColor.WHITE))
                        .append(msg)));
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if ((mgr.gameOf(p) == null && plugin.queues().roomOf(p) == null) || p.hasPermission("bedwars.admin")) return;
        String m = e.getMessage().toLowerCase();
        if (m.startsWith("/bw") || m.startsWith("/bedwars")) return;
        e.setCancelled(true);
        Msg.send(p, "&cPerintah dinonaktifkan selama bermain. Gunakan /bw leave.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        fireballCooldown.remove(id);
        plugin.cooldowns().clear(id);
        plugin.queues().leave(p, true);
        Game g = mgr.gameOf(p);
        if (g != null) g.leave(p, true);
        plugin.lobbyBoard().forget(p);
    }
}
