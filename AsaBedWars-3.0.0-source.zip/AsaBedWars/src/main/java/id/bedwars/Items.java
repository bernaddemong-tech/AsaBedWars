package id.bedwars;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class Items {
    private Items() {}

    public static ItemStack unbreakable(ItemStack i) {
        ItemMeta m = i.getItemMeta();
        if (m != null) {
            m.setUnbreakable(true);
            i.setItemMeta(m);
        }
        return i;
    }

    /** Armor kulit berwarna sesuai tim. */
    public static ItemStack leather(Material mat, BWTeam t) {
        ItemStack i = new ItemStack(mat);
        LeatherArmorMeta m = (LeatherArmorMeta) i.getItemMeta();
        m.setColor(t.color);
        m.setUnbreakable(true);
        m.displayName(Msg.item(t.legacy() + t.display + " Armor"));
        i.setItemMeta(m);
        return i;
    }

    public static ItemStack named(Material mat, int amount, String name, List<String> lore) {
        return named(mat, amount, name, lore, false);
    }

    public static ItemStack named(Material mat, int amount, String name, List<String> lore, boolean glow) {
        ItemStack i = new ItemStack(mat, amount);
        ItemMeta m = i.getItemMeta();
        m.displayName(Msg.item(name));
        if (lore != null) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(Msg.item(s));
            m.lore(l);
        }
        if (glow) m.setEnchantmentGlintOverride(true);
        i.setItemMeta(m);
        return i;
    }

    /** Item khusus waiting lobby (Vote Map / Quit). Dikenali lewat PersistentDataContainer. */
    public static ItemStack special(NamespacedKey key, String id, Material mat, String name) {
        ItemStack i = named(mat, 1, name, null);
        ItemMeta m = i.getItemMeta();
        m.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        i.setItemMeta(m);
        return i;
    }
}
