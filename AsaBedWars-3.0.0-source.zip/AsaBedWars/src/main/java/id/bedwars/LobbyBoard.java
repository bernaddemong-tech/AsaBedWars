package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Scoreboard "Lobby BedWars": hanya tampil untuk pemain yang TIDAK sedang di waiting lobby / game,
 * dan hanya di world yang diatur di config (lobby-scoreboard.worlds) dan/atau world /bw setmainlobby.
 * Waiting & in-game dirender oleh WaitingRoom / Game lewat BoardService yang sama.
 */
public class LobbyBoard {
    private static final List<String> DEFAULT_LINES = List.of(
            "", "&6Wins : &f{wins}", "&6Kills : &f{kills}", "&6Name : &f{name}", "", "&bplay.asamc.my.id");

    private final AsaBedWars plugin;
    private final Set<UUID> shown = new HashSet<>();
    private BukkitTask task;

    public LobbyBoard(AsaBedWars plugin) { this.plugin = plugin; }

    public void start() {
        if (task == null) task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public void shutdown() {
        if (task != null) { task.cancel(); task = null; }
        for (UUID id : shown) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) plugin.boards().removeIfOwned(p);
        }
        shown.clear();
    }

    /** Dipanggil saat pemain keluar server. */
    public void forget(Player p) {
        shown.remove(p.getUniqueId());
        plugin.boards().removeIfOwned(p);
    }

    /** world (huruf kecil) tempat scoreboard lobby boleh muncul. */
    private Set<String> worlds() {
        if (!plugin.getConfig().getBoolean("lobby-scoreboard.enabled", true)) return Set.of();
        Set<String> s = new HashSet<>();
        for (String w : plugin.getConfig().getStringList("lobby-scoreboard.worlds")) s.add(w.toLowerCase());
        if (plugin.getConfig().getBoolean("lobby-scoreboard.use-main-lobby-world", true)) {
            LobbyManager.Spot m = plugin.lobby().mainSpot();
            if (m != null) s.add(m.world().toLowerCase());
        }
        return s;
    }

    private void tick() {
        Set<String> worlds = worlds();
        for (Player p : Bukkit.getOnlinePlayers()) apply(p, worlds);
    }

    public void update(Player p) { apply(p, worlds()); }

    public void updateLater(Player p) {
        if (!plugin.isEnabled()) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) update(p); }, 2L);
    }

    private void apply(Player p, Set<String> worlds) {
        UUID id = p.getUniqueId();
        // saat di waiting lobby / game, scoreboard dipegang WaitingRoom / Game
        if (plugin.queues().roomOf(p) != null || plugin.arenas().gameOf(p) != null) {
            shown.remove(id);
            return;
        }
        if (worlds.contains(p.getWorld().getName().toLowerCase())) {
            render(p);
            shown.add(id);
        } else if (shown.remove(id)) {
            plugin.boards().removeIfOwned(p);   // tidak menimpa scoreboard plugin lain (mis. AsaLobbyCore)
        }
    }

    private void render(Player p) {
        List<String> raw = plugin.getConfig().getStringList("lobby-scoreboard.lines");
        if (raw.isEmpty()) raw = DEFAULT_LINES;
        StatsManager.Stats st = plugin.stats().peek(p.getUniqueId());
        List<String> lines = new ArrayList<>();
        for (String l : raw) lines.add(fill(l, p, st));
        String title = plugin.getConfig().getString("lobby-scoreboard.title", "&e&lBEDWARS");
        plugin.boards().render(p, title, lines, Map.of());
    }

    private String fill(String line, Player p, StatsManager.Stats st) {
        return line
                .replace("{name}", p.getName())
                .replace("{wins}", String.valueOf(st.wins))
                .replace("{kills}", String.valueOf(st.kills))
                .replace("{finalkills}", String.valueOf(st.finalKills))
                .replace("{deaths}", String.valueOf(st.deaths))
                .replace("{beds}", String.valueOf(st.beds))
                .replace("{games}", String.valueOf(st.games))
                .replace("{kdr}", String.valueOf(st.kdr()))
                .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("{domain}", plugin.getConfig().getString("server-domain", "asamc.my.id"));
    }
}
