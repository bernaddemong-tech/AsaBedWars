package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

/**
 * Waiting lobby: item khusus (Vote Map / Quit), GUI mode & vote, kunci inventory,
 * serta proteksi block untuk world arena (enabled) dan world WaitingLobby.
 * Pemain yang sedang di dalam Game ditangani GameListener.
 */
public class LobbyListener implements Listener {
    private final AsaBedWars plugin;

    public LobbyListener(AsaBedWars plugin) { this.plugin = plugin; }

    private boolean inRoom(Player p) { return plugin.queues().roomOf(p) != null; }

    private boolean bypass(Player p) {
        return p.getGameMode() == GameMode.CREATIVE && p.hasPermission("bedwars.bypass");
    }

    /** true jika aksi build/break pemain (di luar game) harus dibatalkan. */
    private boolean blocked(Player p, World w) {
        if (plugin.arenas().gameOf(p) != null) return false;        // aturan game dipegang GameListener
        if (inRoom(p)) return true;
        return plugin.arenas().isProtectedWorld(w) && !bypass(p);
    }

    // ---------- item khusus ----------
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() == Action.PHYSICAL) return;
        ItemStack it = e.getItem();
        if (it == null || !it.hasItemMeta()) return;
        String id = it.getItemMeta().getPersistentDataContainer().get(plugin.itemKey, PersistentDataType.STRING);
        if (id == null) return;

        e.setCancelled(true);                      // item khusus tidak menjalankan fungsi vanilla (mis. memasang bed)
        e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
        e.setUseInteractedBlock(org.bukkit.event.Event.Result.DENY);
        if (e.getHand() != EquipmentSlot.HAND) return;

        Player p = e.getPlayer();
        WaitingRoom room = plugin.queues().roomOf(p);
        if (room == null) {                        // item nyasar (mis. sisa crash) -> hapus
            p.getInventory().setItemInMainHand(null);
            return;
        }
        if (!plugin.cooldowns().tryUse(p.getUniqueId(), 400)) return;   // anti spam
        switch (id) {
            case "vote" -> VoteMenu.open(p, room);
            case "quit" -> plugin.queues().leave(p, false);
            default -> { }
        }
    }

    // ---------- GUI ----------
    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryHolder h = e.getInventory().getHolder();
        boolean top = e.getClickedInventory() != null && e.getClickedInventory().equals(e.getInventory());

        if (h instanceof ModeMenu mm) {
            e.setCancelled(true);
            if (!top) return;
            Mode m = mm.modeAt(e.getSlot());
            if (m == null || !plugin.cooldowns().tryUse(p.getUniqueId(), 600)) return;
            Bukkit.getScheduler().runTask(plugin, () -> {
                p.closeInventory();
                plugin.queues().join(p, m);
            });
            return;
        }
        if (h instanceof VoteMenu vm) {
            e.setCancelled(true);
            if (!top) return;
            Arena a = vm.arenaAt(e.getSlot());
            if (a == null || !plugin.cooldowns().tryUse(p.getUniqueId(), 600)) return;   // anti spam vote
            WaitingRoom room = plugin.queues().roomOf(p);
            if (room == null || room != vm.room()) { p.closeInventory(); return; }        // vote hanya untuk antrean sendiri
            switch (room.vote(p, a)) {
                case OK -> {
                    Msg.send(p, "&aVote untuk &e" + a.mapName() + " &adicatat.");
                    p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
                    room.render();
                    room.refreshMenus();
                }
                case SAME -> Msg.send(p, "&7Kamu sudah vote map ini.");
                case BUSY -> Msg.send(p, "&cMap ini sedang dimainkan.");
                case INVALID -> Msg.send(p, "&cMap tidak tersedia untuk mode ini.");
                case CLOSED -> p.closeInventory();
            }
            return;
        }
        if (inRoom(p)) e.setCancelled(true);       // kunci inventory selama di waiting lobby
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryHolder h = e.getInventory().getHolder();
        if (inRoom(p) || h instanceof ModeMenu || h instanceof VoteMenu) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) { if (inRoom(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) { if (inRoom(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && inRoom(p)) e.setCancelled(true);
    }

    // ---------- status pemain di waiting lobby ----------
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        WaitingRoom r = plugin.queues().roomOf(p);
        if (r == null) return;
        e.setCancelled(true);
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
            Location l = r.hubLocation();
            if (l != null) p.teleport(l);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && inRoom(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && inRoom(p)) e.setCancelled(true);
    }

    // ---------- proteksi block (arena enabled + waiting lobby) ----------
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (blocked(e.getPlayer(), e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (blocked(e.getPlayer(), e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (blocked(e.getPlayer(), e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (blocked(e.getPlayer(), e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (plugin.arenas().isProtectedWorld(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (plugin.arenas().isProtectedWorld(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        plugin.lobbyBoard().updateLater(e.getPlayer());   // scoreboard lobby ikut world
    }

    // ---------- pemulihan: pemain login di world lobby/arena tanpa sesi (mis. setelah crash) ----------
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.lobbyBoard().updateLater(p);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline() || inRoom(p) || plugin.arenas().gameOf(p) != null) return;
            if (plugin.arenas().isProtectedWorld(p.getWorld()) && !bypass(p)) plugin.lobby().exit(p, false);
        }, 5L);
    }
}
