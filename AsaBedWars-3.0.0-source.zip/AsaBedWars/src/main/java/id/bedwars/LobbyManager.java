package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * WaitingLobby (maks 3 hub per mode), lobby utama, serta reset/keluar pemain.
 * Lokasi disimpan sebagai nama world + koordinat (lobbies.yml) dan di-resolve saat dipakai,
 * jadi aman terhadap urutan load world Multiverse.
 */
public class LobbyManager {
    public static final int MAX_HUBS = 3;

    public record Spot(String world, double x, double y, double z, float yaw, float pitch) {
        public static Spot of(Location l) {
            return new Spot(l.getWorld().getName(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch());
        }

        public Location toLocation() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : new Location(w, x, y, z, yaw, pitch);
        }
    }

    private record Origin(ItemStack[] contents, Location loc, GameMode mode, int level, float exp) {}

    private final AsaBedWars plugin;
    private final File file;
    private final Map<Mode, Map<Integer, Spot>> hubs = new EnumMap<>(Mode.class);
    private Spot main;
    private final Map<UUID, Origin> origins = new HashMap<>();

    public LobbyManager(AsaBedWars plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "lobbies.yml");
    }

    // ---------- persistence ----------
    public void load() {
        hubs.clear();
        main = null;
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        main = readSpot(y.getConfigurationSection("main-lobby"));
        ConfigurationSection hs = y.getConfigurationSection("hubs");
        if (hs == null) return;
        for (String mk : hs.getKeys(false)) {
            Mode m = Mode.parse(mk);
            ConfigurationSection ms = hs.getConfigurationSection(mk);
            if (m == null || ms == null) continue;
            for (String ik : ms.getKeys(false)) {
                int idx;
                try { idx = Integer.parseInt(ik); } catch (NumberFormatException ex) { continue; }
                if (idx < 1 || idx > MAX_HUBS) continue;
                Spot s = readSpot(ms.getConfigurationSection(ik));
                if (s != null) hubs.computeIfAbsent(m, k -> new TreeMap<>()).put(idx, s);
            }
        }
    }

    private Spot readSpot(ConfigurationSection s) {
        if (s == null) return null;
        String w = s.getString("world");
        if (w == null || w.isBlank()) return null;
        return new Spot(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
    }

    private void writeSpot(YamlConfiguration y, String path, Spot s) {
        y.set(path + ".world", s.world());
        y.set(path + ".x", s.x());
        y.set(path + ".y", s.y());
        y.set(path + ".z", s.z());
        y.set(path + ".yaw", (double) s.yaw());
        y.set(path + ".pitch", (double) s.pitch());
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        if (main != null) writeSpot(y, "main-lobby", main);
        for (Map.Entry<Mode, Map<Integer, Spot>> e : hubs.entrySet()) {
            for (Map.Entry<Integer, Spot> h : e.getValue().entrySet()) {
                writeSpot(y, "hubs." + e.getKey().name() + "." + h.getKey(), h.getValue());
            }
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Gagal menyimpan lobbies.yml: " + ex.getMessage());
        }
    }

    // ---------- hubs ----------
    public void setHub(Mode m, int idx, Location l) {
        hubs.computeIfAbsent(m, k -> new TreeMap<>()).put(idx, Spot.of(l));
        save();
    }

    public boolean removeHub(Mode m, int idx) {
        Map<Integer, Spot> map = hubs.get(m);
        if (map == null || map.remove(idx) == null) return false;
        save();
        return true;
    }

    public List<Integer> hubIndexes(Mode m) {
        Map<Integer, Spot> map = hubs.get(m);
        return map == null ? new ArrayList<>() : new ArrayList<>(map.keySet());
    }

    public Spot hubSpot(Mode m, int idx) {
        Map<Integer, Spot> map = hubs.get(m);
        return map == null ? null : map.get(idx);
    }

    /** Lokasi hub, null jika belum diset atau world-nya belum dimuat. */
    public Location hubLocation(Mode m, int idx) {
        Spot s = hubSpot(m, idx);
        return s == null ? null : s.toLocation();
    }

    public boolean isLobbyWorld(String worldName) {
        for (Map<Integer, Spot> map : hubs.values()) {
            for (Spot s : map.values()) if (s.world().equals(worldName)) return true;
        }
        return false;
    }

    public String configuredWorld(Mode m) {
        String s = plugin.getConfig().getString("waiting.world-names." + m.name());
        return s == null || s.isBlank() ? null : s;
    }

    /** null jika world boleh dipakai sebagai WaitingLobby mode ini, selain itu alasannya. */
    public String checkWaitingWorld(Mode m, World w) {
        if (plugin.arenas().isArenaWorld(w.getName())) {
            return "World '" + w.getName() + "' dipakai arena. WaitingLobby harus di world terpisah.";
        }
        String cfg = configuredWorld(m);
        if (plugin.getConfig().getBoolean("waiting.enforce-world-names", true)
                && cfg != null && !cfg.equalsIgnoreCase(w.getName())) {
            return "WaitingLobby " + m.display + " harus di world '" + cfg + "' (ubah di config.yml: waiting.world-names."
                    + m.name() + ", atau set waiting.enforce-world-names: false).";
        }
        return null;
    }

    // ---------- lobby utama ----------
    public void setMain(Location l) { main = Spot.of(l); save(); }
    public boolean hasMain() { return main != null; }
    public Spot mainSpot() { return main; }
    public Location mainLocation() { return main == null ? null : main.toLocation(); }

    // ---------- reset & keluar ----------
    /** Reset total status pertandingan: item, armor, efek, health, food, xp. */
    public void fullReset(Player p) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand(new ItemStack(Material.AIR));
        p.setItemOnCursor(new ItemStack(Material.AIR));
        for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
        p.setHealth(20);
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setExhaustion(0f);
        p.setFireTicks(0);
        p.setFreezeTicks(0);
        p.setFallDistance(0f);
        p.setLevel(0);
        p.setExp(0f);
    }

    /** Catat posisi/inventory asal saat pertama kali masuk antrean (sekali per sesi). */
    public void capture(Player p) {
        if (origins.containsKey(p.getUniqueId())) return;
        boolean keep = plugin.getConfig().getBoolean("exit.restore-inventory", false);
        origins.put(p.getUniqueId(), new Origin(keep ? p.getInventory().getContents() : null,
                p.getLocation(), p.getGameMode(), p.getLevel(), p.getExp()));
    }

    /** Keluarkan pemain dari sistem BedWars: reset penuh lalu ke lobby utama. */
    public void exit(Player p, boolean immediate) {
        Origin o = origins.remove(p.getUniqueId());
        plugin.boards().remove(p);
        p.displayName(null);
        p.playerListName(null);

        Location dest = mainLocation();
        if (dest == null && o != null && o.loc().getWorld() != null) dest = o.loc();
        if (dest == null) dest = Bukkit.getWorlds().get(0).getSpawnLocation();
        final Location target = dest;

        boolean restore = plugin.getConfig().getBoolean("exit.restore-inventory", false);
        GameMode gm;
        try {
            gm = GameMode.valueOf(plugin.getConfig().getString("exit.gamemode", "SURVIVAL").toUpperCase());
        } catch (IllegalArgumentException ex) {
            gm = GameMode.SURVIVAL;
        }
        final GameMode finalMode = gm;

        Runnable apply = () -> {
            if (!p.isOnline()) return;
            fullReset(p);
            if (restore && o != null && o.contents() != null) {
                p.getInventory().setContents(o.contents());
                p.setLevel(o.level());
                p.setExp(o.exp());
                p.setGameMode(o.mode());
            } else {
                p.setGameMode(finalMode);
            }
        };
        if (immediate || !plugin.isEnabled()) {
            p.teleport(target);
            apply.run();
        } else {
            plugin.teleportThen(p, target, apply);
            plugin.lobbyBoard().updateLater(p);
        }
    }
}
