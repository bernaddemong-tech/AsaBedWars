package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** GUI "Select Gamemode": Solo, Duo, Squad (1v1 hanya muncul jika WaitingLobby-nya diset). */
public class ModeMenu implements InventoryHolder {
    private final Inventory inv;
    private final Map<Integer, Mode> slots = new HashMap<>();

    private ModeMenu(AsaBedWars plugin) {
        inv = Bukkit.createInventory(this, 27, Msg.c("&6&lSelect Gamemode"));
        put(plugin, 11, Mode.SOLO, Material.IRON_SWORD);
        put(plugin, 13, Mode.DUO, Material.GOLDEN_SWORD);
        put(plugin, 15, Mode.SQUAD, Material.DIAMOND_SWORD);
        if (!plugin.lobby().hubIndexes(Mode.DUEL).isEmpty()) put(plugin, 22, Mode.DUEL, Material.NETHERITE_SWORD);
    }

    private void put(AsaBedWars plugin, int slot, Mode m, Material icon) {
        int maps = plugin.arenas().arenasFor(m).size();
        boolean ready = maps > 0 && !plugin.lobby().hubIndexes(m).isEmpty();
        inv.setItem(slot, Items.named(icon, 1, "&e&l" + m.display, List.of(
                "&7Pemain per tim: &f" + m.teamSize,
                "&7Map tersedia: &f" + maps,
                "&7Sedang menunggu: &f" + plugin.queues().waitingCount(m),
                "",
                ready ? "&aKlik untuk bermain" : "&cBelum tersedia")));
        slots.put(slot, m);
    }

    public Mode modeAt(int slot) { return slots.get(slot); }

    public static void open(Player p, AsaBedWars plugin) { p.openInventory(new ModeMenu(plugin).inv); }

    @Override
    public Inventory getInventory() { return inv; }
}
