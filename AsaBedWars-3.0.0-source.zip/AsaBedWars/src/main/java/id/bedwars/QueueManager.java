package id.bedwars;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Mengelola semua WaitingRoom (per mode, maks 3 hub) dan keanggotaan antrean pemain. */
public class QueueManager {
    private final AsaBedWars plugin;
    private final Map<Mode, Map<Integer, WaitingRoom>> rooms = new EnumMap<>(Mode.class);
    private final Map<UUID, WaitingRoom> byPlayer = new ConcurrentHashMap<>();

    public QueueManager(AsaBedWars plugin) { this.plugin = plugin; }

    public WaitingRoom roomOf(Player p) { return byPlayer.get(p.getUniqueId()); }
    public WaitingRoom roomOf(UUID id) { return byPlayer.get(id); }
    public void bind(UUID id, WaitingRoom r) { byPlayer.put(id, r); }
    public void unbind(UUID id) { byPlayer.remove(id); }

    public List<WaitingRoom> allRooms() {
        List<WaitingRoom> l = new ArrayList<>();
        for (Map<Integer, WaitingRoom> m : rooms.values()) l.addAll(m.values());
        return l;
    }

    public int waitingCount(Mode mode) {
        int n = 0;
        Map<Integer, WaitingRoom> m = rooms.get(mode);
        if (m != null) for (WaitingRoom r : m.values()) n += r.size();
        return n;
    }

    private WaitingRoom room(Mode mode, int idx) {
        return rooms.computeIfAbsent(mode, k -> new TreeMap<>()).computeIfAbsent(idx, i -> new WaitingRoom(plugin, mode, i));
    }

    public void join(Player p, Mode mode) {
        if (plugin.arenas().gameOf(p) != null) { Msg.send(p, "&cKamu sedang berada di dalam game."); return; }
        if (roomOf(p) != null) { Msg.send(p, "&cKamu sudah di antrean. Gunakan item Keluar atau /bw leave."); return; }
        if (plugin.arenas().arenasFor(mode).isEmpty()) {
            Msg.send(p, "&cBelum ada arena aktif untuk mode &e" + mode.display + "&c.");
            return;
        }
        List<Integer> idxs = plugin.lobby().hubIndexes(mode);
        if (idxs.isEmpty()) { Msg.send(p, "&cWaitingLobby mode &e" + mode.display + " &cbelum diset."); return; }

        WaitingRoom best = null;
        boolean anyReady = false;
        for (int idx : idxs) {
            Location l = plugin.lobby().hubLocation(mode, idx);
            if (l == null) continue;                       // world belum dimuat
            anyReady = true;
            WaitingRoom r = room(mode, idx);
            if (!r.joinable()) continue;
            if (best == null || r.size() > best.size()) best = r;   // isi hub yang sudah ramai dulu
        }
        if (!anyReady) { Msg.send(p, "&cWorld WaitingLobby belum dimuat. Hubungi admin."); return; }
        if (best == null) { Msg.send(p, "&cSemua waiting lobby " + mode.display + " penuh. Coba lagi sebentar."); return; }
        best.add(p);
    }

    /** @return true jika pemain memang sedang di antrean. */
    public boolean leave(Player p, boolean immediate) {
        WaitingRoom r = byPlayer.get(p.getUniqueId());
        if (r == null) return false;
        r.remove(p, immediate);
        return true;
    }

    public void shutdown() {
        for (WaitingRoom r : allRooms()) r.shutdown();
        byPlayer.clear();
    }
}
