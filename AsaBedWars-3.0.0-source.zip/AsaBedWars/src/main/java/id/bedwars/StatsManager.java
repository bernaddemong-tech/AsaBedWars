package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Statistik pemain (wins, kills, dst) disimpan di stats.yml; dipakai scoreboard Lobby & /bw stats. */
public class StatsManager {
    public static final class Stats {
        public String name = "";
        public int wins, kills, finalKills, deaths, beds, games;

        public double kdr() {
            return deaths == 0 ? kills : Math.round(kills * 100.0 / deaths) / 100.0;
        }
    }

    private static final Stats EMPTY = new Stats();   // hanya dibaca, tidak pernah diubah

    private final AsaBedWars plugin;
    private final File file;
    private final Map<UUID, Stats> map = new HashMap<>();
    private boolean dirty;
    private BukkitTask saver;

    public StatsManager(AsaBedWars plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
    }

    public void load() {
        map.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("players");
        if (root == null) return;
        for (String k : root.getKeys(false)) {
            UUID id;
            try { id = UUID.fromString(k); } catch (IllegalArgumentException ex) { continue; }
            ConfigurationSection s = root.getConfigurationSection(k);
            if (s == null) continue;
            Stats st = new Stats();
            st.name = s.getString("name", "");
            st.wins = s.getInt("wins");
            st.kills = s.getInt("kills");
            st.finalKills = s.getInt("final-kills");
            st.deaths = s.getInt("deaths");
            st.beds = s.getInt("beds");
            st.games = s.getInt("games");
            map.put(id, st);
        }
    }

    /** Simpan otomatis tiap 5 menit jika ada perubahan. */
    public void start() {
        if (saver == null) saver = Bukkit.getScheduler().runTaskTimer(plugin, () -> { if (dirty) save(); }, 6000L, 6000L);
    }

    public void shutdown() {
        if (saver != null) { saver.cancel(); saver = null; }
        if (dirty) save();
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Stats> e : map.entrySet()) {
            String b = "players." + e.getKey() + ".";
            Stats s = e.getValue();
            y.set(b + "name", s.name);
            y.set(b + "wins", s.wins);
            y.set(b + "kills", s.kills);
            y.set(b + "final-kills", s.finalKills);
            y.set(b + "deaths", s.deaths);
            y.set(b + "beds", s.beds);
            y.set(b + "games", s.games);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().severe("Gagal menyimpan stats.yml: " + ex.getMessage());
        }
    }

    /** Baca statistik tanpa membuat entri baru. */
    public Stats peek(UUID id) {
        Stats s = map.get(id);
        return s == null ? EMPTY : s;
    }

    private Stats mut(UUID id, String name) {
        Stats s = map.computeIfAbsent(id, k -> new Stats());
        if (name != null && !name.isEmpty()) s.name = name;
        dirty = true;
        return s;
    }

    public void addKill(UUID id, String name, boolean finalKill) {
        Stats s = mut(id, name);
        s.kills++;
        if (finalKill) s.finalKills++;
    }

    public void addDeath(UUID id, String name) { mut(id, name).deaths++; }
    public void addBed(UUID id, String name) { mut(id, name).beds++; }
    public void addGame(UUID id, String name) { mut(id, name).games++; }
    public void addWin(UUID id, String name) { mut(id, name).wins++; }
}
