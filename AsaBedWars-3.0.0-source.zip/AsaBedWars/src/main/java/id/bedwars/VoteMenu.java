package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** GUI Vote Map: hanya map bermode sama dengan antrean pemain; jumlah vote diperbarui berkala. */
public class VoteMenu implements InventoryHolder {
    private final Inventory inv;
    private final WaitingRoom room;
    private final Player viewer;
    private final List<Arena> arenas;

    private VoteMenu(WaitingRoom room, Player viewer, List<Arena> arenas) {
        this.room = room;
        this.viewer = viewer;
        this.arenas = arenas;
        int size = Math.min(54, Math.max(9, (int) Math.ceil(arenas.size() / 9.0) * 9));
        inv = Bukkit.createInventory(this, size, Msg.c("&6&lVote Map &8- &f" + room.mode.display));
        refresh();
    }

    public static void open(Player p, WaitingRoom room) {
        List<Arena> list = room.candidates();
        if (list.isEmpty()) { Msg.send(p, "&cBelum ada map untuk mode ini."); return; }
        p.openInventory(new VoteMenu(room, p, new ArrayList<>(list)).inv);
    }

    public WaitingRoom room() { return room; }

    public Arena arenaAt(int slot) { return slot >= 0 && slot < arenas.size() ? arenas.get(slot) : null; }

    /** Perbarui jumlah vote & tanda pilihan pemain tanpa menutup GUI. */
    public void refresh() {
        Map<String, Integer> counts = room.counts();
        String mine = room.voteOf(viewer);
        for (int i = 0; i < arenas.size() && i < inv.getSize(); i++) {
            Arena a = arenas.get(i);
            String key = a.name.toLowerCase();
            int v = counts.getOrDefault(key, 0);
            boolean selected = key.equals(mine);
            boolean busy = room.busy(a);
            String hint = selected ? "&aVote kamu" : busy ? "&cSedang dimainkan" : "&eKlik untuk vote";
            inv.setItem(i, Items.named(Material.MAP, Math.min(64, Math.max(1, v)),
                    (selected ? "&a&l" : "&f&l") + a.mapName(),
                    List.of("&7Mode: &f" + a.mode.display,
                            "&7Kapasitas: &f" + a.maxPlayers(),
                            "&7Vote: &e" + v,
                            "",
                            hint), selected));
        }
    }

    @Override
    public Inventory getInventory() { return inv; }
}
