package id.bedwars;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Satu waiting lobby (mode + nomor hub): menampung pemain, voting map, countdown, lalu meluncurkan Game. */
public class WaitingRoom {
    public enum State { WAITING, STARTING }
    public enum VoteResult { OK, SAME, INVALID, BUSY, CLOSED }

    private static final int SLOT_VOTE = 4;   // slot Minecraft 5 (1-based)
    private static final int SLOT_QUIT = 8;   // slot Minecraft 9 (1-based)

    private final AsaBedWars plugin;
    public final Mode mode;
    public final int hub;
    private State state = State.WAITING;
    private final Set<UUID> players = new LinkedHashSet<>();
    private final Map<UUID, String> votes = new HashMap<>();
    private BukkitTask task;
    private int countdown;

    public WaitingRoom(AsaBedWars plugin, Mode mode, int hub) {
        this.plugin = plugin;
        this.mode = mode;
        this.hub = hub;
    }

    // ---------- info ----------
    public State state() { return state; }
    public int size() { return players.size(); }
    public boolean contains(UUID id) { return players.contains(id); }
    public Location hubLocation() { return plugin.lobby().hubLocation(mode, hub); }
    public List<Arena> candidates() { return plugin.arenas().arenasFor(mode); }

    public int capacity() {
        int max = 0;
        for (Arena a : candidates()) max = Math.max(max, a.maxPlayers());
        return max;
    }

    public boolean joinable() { return players.size() < capacity(); }

    public int minStart() {
        int m = Integer.MAX_VALUE;
        for (Arena a : candidates()) m = Math.min(m, a.minPlayers);
        if (m == Integer.MAX_VALUE) m = 2;
        return Math.max(Math.max(2, m), plugin.getConfig().getInt("queue.min-players", 2));
    }

    public boolean busy(Arena a) {
        Game g = plugin.arenas().game(a);
        return g != null && !g.isIdle();
    }

    public void broadcast(String legacy) {
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.sendMessage(Msg.c(Msg.PREFIX + legacy));
        }
    }

    // ---------- players ----------
    public void add(Player p) {
        UUID id = p.getUniqueId();
        players.add(id);
        plugin.lobby().capture(p);
        plugin.queues().bind(id, this);
        p.closeInventory();

        Location loc = hubLocation();
        plugin.teleportThen(p, loc, () -> {
            if (!players.contains(id) || !p.isOnline()) return;
            plugin.lobby().fullReset(p);
            p.setGameMode(GameMode.ADVENTURE);
            giveHotbar(p);
            plugin.boards().refreshLater(p);
        });

        broadcast("&e" + p.getName() + " &7bergabung &8(" + players.size() + "/" + capacity() + ")");
        if (BedrockUtil.isBedrock(p)) Msg.send(p, "&7Ketuk item Kertas untuk Vote Map, Kasur Merah untuk keluar.");
        ensureTask();
        render();
    }

    private void giveHotbar(Player p) {
        p.getInventory().setItem(SLOT_VOTE, Items.special(plugin.itemKey, "vote", Material.PAPER, "&aVote Map &7(klik)"));
        p.getInventory().setItem(SLOT_QUIT, Items.special(plugin.itemKey, "quit", Material.RED_BED, "&cKeluar &7(klik)"));
    }

    public void remove(Player p, boolean immediate) {
        UUID id = p.getUniqueId();
        if (!players.remove(id)) return;
        votes.remove(id);
        plugin.queues().unbind(id);
        plugin.lobby().exit(p, immediate);
        broadcast("&e" + p.getName() + " &7keluar dari antrean.");
        afterChange();
    }

    private void afterChange() {
        if (players.isEmpty()) {
            stopTask();
            state = State.WAITING;
            countdown = 0;
        } else {
            render();
            refreshMenus();
        }
    }

    // ---------- voting ----------
    public String voteOf(Player p) { return votes.get(p.getUniqueId()); }

    public Map<String, Integer> counts() {
        Map<String, Integer> c = new HashMap<>();
        for (String k : votes.values()) c.merge(k, 1, Integer::sum);
        return c;
    }

    public VoteResult vote(Player p, Arena a) {
        UUID id = p.getUniqueId();
        if (!players.contains(id) || (state != State.WAITING && state != State.STARTING)) return VoteResult.CLOSED;
        if (!candidates().contains(a)) return VoteResult.INVALID;   // map harus sesuai mode antrean
        if (busy(a)) return VoteResult.BUSY;
        String key = a.name.toLowerCase();
        String old = votes.put(id, key);                             // satu vote aktif per pemain
        return key.equals(old) ? VoteResult.SAME : VoteResult.OK;
    }

    private Arena resolve() {
        int n = players.size();
        Map<String, Integer> counts = counts();
        List<Arena> eligible = new ArrayList<>();
        for (Arena a : candidates()) {
            if (!busy(a) && a.minPlayers <= n && a.maxPlayers() >= n) eligible.add(a);
        }
        if (eligible.isEmpty()) return null;
        int best = 0;
        for (Arena a : eligible) best = Math.max(best, counts.getOrDefault(a.name.toLowerCase(), 0));
        List<Arena> top = new ArrayList<>();
        for (Arena a : eligible) {
            if (counts.getOrDefault(a.name.toLowerCase(), 0) == best) top.add(a);   // best==0 -> semua eligible
        }
        return top.get(ThreadLocalRandom.current().nextInt(top.size()));            // seri / tanpa vote -> acak
    }

    public void refreshMenus() {
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            Inventory top = p.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof VoteMenu vm && vm.room() == this) vm.refresh();
        }
    }

    // ---------- loop ----------
    private void ensureTask() {
        if (task == null) task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private void stopTask() {
        if (task != null) { task.cancel(); task = null; }
    }

    private void tick() {
        if (players.isEmpty()) { stopTask(); return; }
        int min = minStart();
        if (state == State.WAITING) {
            if (players.size() >= min) {
                state = State.STARTING;
                countdown = plugin.getConfig().getInt("countdown", 15);
            }
        } else {
            if (players.size() < min) {
                state = State.WAITING;
                broadcast("&cPemain kurang, hitung mundur dibatalkan.");
            } else {
                int fullCd = plugin.getConfig().getInt("queue.full-countdown", 5);
                if (players.size() >= capacity() && countdown > fullCd) countdown = fullCd;
                if (countdown <= 0) { launch(); return; }
                if (countdown <= 5 || countdown % 10 == 0) {
                    for (UUID id : players) {
                        Player p = Bukkit.getPlayer(id);
                        if (p == null) continue;
                        p.showTitle(Title.title(Msg.c("&e" + countdown), Msg.c("&7Bersiap..."),
                                Title.Times.times(Duration.ZERO, Duration.ofMillis(900), Duration.ZERO)));
                        p.playSound(p.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 1f, 1f);
                    }
                }
                countdown--;
            }
        }
        render();
        refreshMenus();
    }

    private void launch() {
        Arena a = resolve();
        if (a == null) {
            broadcast("&cBelum ada arena kosong yang cocok. Mencoba lagi sebentar...");
            countdown = 10;
            return;
        }
        List<Player> ps = new ArrayList<>();
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) ps.add(p);
        }
        if (ps.size() < 2) { countdown = 10; return; }

        int got = counts().getOrDefault(a.name.toLowerCase(), 0);
        Game g = plugin.arenas().gameFor(a);

        // pindahkan semua pemain ke Game: room dikosongkan & di-reset lebih dulu
        for (Player p : ps) {
            plugin.queues().unbind(p.getUniqueId());
            p.closeInventory();
        }
        players.clear();
        votes.clear();
        state = State.WAITING;
        countdown = 0;
        stopTask();

        for (Player p : ps) {
            p.sendMessage(Msg.c(Msg.PREFIX + "&aMap terpilih: &e" + a.mapName() + " &7(" + got + " vote)"));
        }
        if (!g.startFromRoom(ps)) {
            // sangat jarang: arena mendadak dipakai -> kembalikan pemain ke antrean ini
            for (Player p : ps) add(p);
        }
    }

    // ---------- scoreboard ----------
    private String leaderLabel() {
        Map<String, Integer> c = counts();
        int best = 0;
        Arena lead = null;
        boolean tie = false;
        for (Arena a : candidates()) {
            int v = c.getOrDefault(a.name.toLowerCase(), 0);
            if (v > best) { best = v; lead = a; tie = false; }
            else if (v == best && v > 0) tie = true;
        }
        if (lead == null) return "&7Voting";
        if (tie) return "&eVoting";
        return "&a" + lead.mapName();
    }

    private List<String> lines() {
        List<String> l = new ArrayList<>();
        l.add("&7" + LocalDate.now().format(DateTimeFormatter.ofPattern("MM/dd/yy")) + " &8" + mode.display + "-" + hub);
        l.add("");
        l.add("&fMap: " + leaderLabel());
        l.add("&fPlayers: &a" + players.size() + "/" + capacity());
        l.add("");
        l.add(state == State.STARTING ? "&fStarting in &a" + Math.max(countdown, 0) + "s" : "&7Waiting for players...");
        l.add("");
        l.add("&fMode: &a" + mode.display);
        l.add("");
        l.add("&e" + plugin.getConfig().getString("server-domain", "asamc.my.id"));
        return l;
    }

    public void render() {
        String title = plugin.getConfig().getString("scoreboard.title-waiting", "&e&lWAITING FOR PLAYER");
        List<String> lines = lines();
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) plugin.boards().render(p, title, lines, Map.of());
        }
    }

    public void shutdown() {
        stopTask();
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            plugin.queues().unbind(id);
            if (p != null) plugin.lobby().exit(p, true);
        }
        players.clear();
        votes.clear();
        state = State.WAITING;
    }
}
