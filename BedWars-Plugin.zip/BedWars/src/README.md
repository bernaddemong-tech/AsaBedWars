# BedWars v2 (Paper 1.21.11 - 26.3) - Java & Bedrock (Geyser/Floodgate)

## Build
    mvn clean package                 # API 1.21.11, bytecode Java 21 -> jalan di 1.21.11 s/d 26.x (Java 21 / 25)
    mvn clean package -Ppaper-26      # build khusus Paper 26.x, Java 25
Hasil: target/BedWars-2.0.0.jar -> taruh di plugins/.

## Alur pemain
    /bw arenas  -> GUI chest berisi arena yang sudah enabled -> klik arena
    -> teleport ke waiting lobby + scoreboard WAITING muncul
    -> game mulai -> scoreboard IN GAME (event berikutnya, tim, domain)

## Setup arena (admin: bedwars.admin)
    /bw create <nama>
    /bw setmode <solo|duo|squad|1v1>
    /bw setwaiting              (berdiri di waiting lobby)
    /bw setspec                 (titik spectator)
    /bw setspawn <tim>          (spawn + generator besi/emas tim)
    /bw setbed <tim>            (lihat bed tim itu)
    /bw addshop                 (NPC Item Shop)
    /bw addupgrade              (NPC Upgrade Tim - opsional, juga ada tombol di Item Shop)
    /bw addgen diamond|emerald
    /bw setmin 2
    /bw info ; /bw enable ; /bw reload
Mode: solo 1/tim (maks 8 tim), duo 2/tim (8 tim), squad 4/tim (4 tim), 1v1 (2 tim x 1).

## Fitur
- Fireball (Fire Charge, klik kanan), TNT, kaca tahan ledak
- Team Upgrade (Diamond): Sharpened Swords, Reinforced Armor I-IV, Maniac Miner I-II, Forge I-IV, Heal Pool
- Armor kulit & nama pemain (nametag, tab list, chat) berwarna sesuai tim
- Event: Diamond II/III, Emerald II/III, Bed Gone, Game End (jadwal di config.yml)
- Scoreboard waiting & in-game tanpa kedip, domain di bawah (config: server-domain)

## Multiverse
- Arena dimuat setelah dunia Multiverse siap; jika dunia belum dimuat arena dikunci (read-only) supaya data tidak hilang -> muat dunia lalu /bw reload.
- Multiverse-Inventories: pengaturan inventory ditunda beberapa tick setelah pindah dunia (config multiverse.inventory-delay-ticks).

## Geyser / Floodgate
- Deteksi Bedrock otomatis via Floodgate (fallback prefix nama). Semua UI = chest GUI & item biasa.
- Simbol scoreboard bisa diganti di config (scoreboard.bed-alive / eliminated) jika font Bedrock tidak menampilkan "√".
