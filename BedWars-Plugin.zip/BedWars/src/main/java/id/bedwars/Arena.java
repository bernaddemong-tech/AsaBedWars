package id.bedwars;

import org.bukkit.Location;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class Arena {
    public final String name;
    public Location waiting, spectator;
    public Mode mode = Mode.SOLO;
    public int minPlayers = 2;
    public boolean enabled = false;
    public final Map<BWTeam, Location> spawns = new EnumMap<>(BWTeam.class);
    public final Map<BWTeam, Location> beds = new EnumMap<>(BWTeam.class);
    public final List<Location> diamondGens = new ArrayList<>();
    public final List<Location> emeraldGens = new ArrayList<>();
    public final List<Location> shops = new ArrayList<>();
    public final List<Location> upgradeShops = new ArrayList<>();

    public Arena(String name) { this.name = name; }

    public String mapName() { return name.replace('_', ' ').replace('-', ' '); }

    /** Tim yang punya spawn + bed. */
    public List<BWTeam> activeTeams() {
        List<BWTeam> l = new ArrayList<>();
        for (BWTeam t : BWTeam.values()) if (spawns.containsKey(t) && beds.containsKey(t)) l.add(t);
        return l;
    }

    /** Tim yang dipakai sesuai mode (mis. 1v1 hanya 2 tim pertama). */
    public List<BWTeam> usedTeams() {
        List<BWTeam> a = activeTeams();
        return a.size() > mode.maxTeams ? new ArrayList<>(a.subList(0, mode.maxTeams)) : a;
    }

    public int maxPlayers() { return usedTeams().size() * mode.teamSize; }

    /** null jika arena siap dipakai, selain itu alasan kenapa belum siap. */
    public String validate() {
        if (waiting == null || waiting.getWorld() == null) return "Waiting lobby belum diset / dunianya belum dimuat (/bw setwaiting).";
        if (spectator == null || spectator.getWorld() == null) return "Spectator belum diset (/bw setspec).";
        if (usedTeams().size() < 2) return "Minimal 2 tim dengan spawn + bed (/bw setspawn, /bw setbed).";
        if (shops.isEmpty()) return "Belum ada shop (/bw addshop).";
        if (minPlayers > maxPlayers()) return "Min pemain (" + minPlayers + ") lebih besar dari kapasitas (" + maxPlayers() + ").";
        return null;
    }
}
