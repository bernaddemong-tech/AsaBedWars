package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.ArrayList;
import java.util.List;

/** Menu pilih arena (chest GUI) - hanya arena yang sudah enabled/siap. */
public class ArenaMenu implements InventoryHolder {
    private final Inventory inv;
    private final List<String> names = new ArrayList<>();

    public ArenaMenu(ArenaManager mgr) {
        List<Arena> list = new ArrayList<>();
        for (Arena a : mgr.all()) if (a.enabled && a.validate() == null) list.add(a);
        int size = Math.min(54, Math.max(9, (int) Math.ceil(list.size() / 9.0) * 9));
        inv = Bukkit.createInventory(this, size, Msg.c("&6&lBedWars - Pilih Arena"));
        int i = 0;
        for (Arena a : list) {
            if (i >= size) break;
            Game g = mgr.game(a);
            Game.State st = g == null ? Game.State.WAITING : g.getState();
            int n = g == null ? 0 : g.size();
            boolean open = st == Game.State.WAITING || st == Game.State.STARTING;
            inv.setItem(i, Items.named(open ? Material.LIME_WOOL : Material.RED_WOOL, 1, "&e" + a.mapName(),
                    List.of("&7Mode: &f" + a.mode.display,
                            "&7Pemain: &f" + n + "/" + a.maxPlayers(),
                            "&7Status: " + (open ? "&aBuka" : "&cBerjalan"),
                            "&8Ketuk untuk join")));
            names.add(a.name);
            i++;
        }
    }

    public String nameAt(int slot) { return slot >= 0 && slot < names.size() ? names.get(slot) : null; }

    public void open(Player p) { p.openInventory(inv); }

    @Override
    public Inventory getInventory() { return inv; }
}
