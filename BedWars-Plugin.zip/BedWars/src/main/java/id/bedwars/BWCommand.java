package id.bedwars;

import org.bukkit.Location;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class BWCommand implements CommandExecutor, TabCompleter {
    private final BedWarsPlugin plugin;
    private final ArenaManager mgr;
    private final Map<UUID, String> editing = new HashMap<>();

    private static final List<String> PLAYER_SUBS = List.of("arenas", "join", "leave", "list", "help");
    private static final List<String> ADMIN_SUBS = List.of("create", "edit", "delete", "setwaiting", "setspec", "setmode",
            "setmin", "setspawn", "setbed", "addgen", "addshop", "addupgrade", "clearshops", "enable", "disable", "info", "reload");

    public BWCommand(BedWarsPlugin plugin, ArenaManager mgr) {
        this.plugin = plugin;
        this.mgr = mgr;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Perintah ini hanya untuk pemain."); return true; }
        if (a.length == 0) { new ArenaMenu(mgr).open(p); return true; }
        switch (a[0].toLowerCase()) {
            case "arenas", "menu" -> {
                if (mgr.gameOf(p) != null) Msg.send(p, "&cKamu sudah berada di dalam game.");
                else new ArenaMenu(mgr).open(p);
            }
            case "join" -> {
                if (a.length < 2) Msg.send(p, "&cGunakan: /bw join <arena> atau /bw arenas"); else mgr.join(p, a[1]);
            }
            case "leave" -> {
                Game g = mgr.gameOf(p);
                if (g == null) Msg.send(p, "&cKamu tidak sedang di dalam game."); else g.leave(p);
            }
            case "list" -> {
                Msg.send(p, "&eArena aktif:");
                for (Arena ar : mgr.all()) {
                    if (!ar.enabled) continue;
                    Game g = mgr.game(ar);
                    p.sendMessage(Msg.c(" &7- &f" + ar.name + " &8[" + ar.mode.display + " "
                            + (g == null ? 0 : g.size()) + "/" + ar.maxPlayers() + "] &7"
                            + (g == null ? Game.State.WAITING : g.getState())));
                }
            }
            case "help" -> help(p);
            default -> admin(p, a);
        }
        return true;
    }

    private void help(Player p) {
        Msg.send(p, "&e/bw arenas &7- pilih arena (GUI)  &e/bw join <arena>  &e/bw leave  &e/bw list");
        if (p.hasPermission("bedwars.admin")) {
            Msg.send(p, "&6Admin: &7create, edit, delete, setwaiting, setspec, setmode <solo|duo|squad|1v1>,");
            Msg.send(p, "&7setmin, setspawn <tim>, setbed <tim> (lihat bed), addgen <diamond|emerald>,");
            Msg.send(p, "&7addshop, addupgrade, clearshops, enable, disable, info, reload");
            Msg.send(p, "&7Tim: " + String.join(", ", Arrays.stream(BWTeam.values()).map(t -> t.name().toLowerCase()).toList()));
        }
    }

    private Arena selected(Player p) {
        String n = editing.get(p.getUniqueId());
        Arena a = n == null ? null : mgr.get(n);
        if (a == null) Msg.send(p, "&cPilih arena dulu: /bw create <nama> atau /bw edit <nama>");
        return a;
    }

    private void admin(Player p, String[] a) {
        if (!p.hasPermission("bedwars.admin")) { Msg.send(p, "&cKamu tidak punya izin. /bw help"); return; }
        String sub = a[0].toLowerCase();

        if (sub.equals("reload")) {
            plugin.reloadConfig();
            mgr.reload();
            Msg.send(p, "&aKonfigurasi & arena dimuat ulang." + (mgr.isReadOnly() ? " &c(masih ada dunia yang belum dimuat)" : ""));
            return;
        }
        if (mgr.isReadOnly() && !sub.equals("info")) {
            Msg.send(p, "&cAda dunia arena yang belum dimuat (Multiverse?). Muat dunianya lalu /bw reload.");
            return;
        }

        switch (sub) {
            case "create" -> {
                if (a.length < 2 || !a[1].matches("[A-Za-z0-9_-]{1,24}")) { Msg.send(p, "&cGunakan: /bw create <nama> (huruf/angka/_/-)"); return; }
                if (mgr.get(a[1]) != null) { Msg.send(p, "&cArena sudah ada."); return; }
                Arena ar = mgr.create(a[1]);
                editing.put(p.getUniqueId(), ar.name);
                Msg.send(p, "&aArena &e" + ar.name + " &adibuat dan dipilih untuk diedit.");
                return;
            }
            case "edit" -> {
                Arena ar = a.length < 2 ? null : mgr.get(a[1]);
                if (ar == null) { Msg.send(p, "&cArena tidak ditemukan."); return; }
                editing.put(p.getUniqueId(), ar.name);
                Msg.send(p, "&aMengedit arena &e" + ar.name);
                return;
            }
            case "delete" -> {
                Arena ar = a.length < 2 ? null : mgr.get(a[1]);
                if (ar == null) { Msg.send(p, "&cArena tidak ditemukan."); return; }
                if (!mgr.delete(ar)) Msg.send(p, "&cMasih ada pemain di arena itu."); else Msg.send(p, "&aArena dihapus.");
                return;
            }
            default -> {}
        }

        Arena ar = selected(p);
        if (ar == null) return;

        switch (sub) {
            case "info" -> {
                Msg.send(p, "&eArena &f" + ar.name + " &7(" + (ar.enabled ? "&aaktif" : "&cnonaktif") + "&7)");
                Msg.send(p, "&7Mode: &f" + ar.mode.display + " &7| Kapasitas: &f" + ar.maxPlayers() + " &7| Min: &f" + ar.minPlayers);
                Msg.send(p, "&7Waiting: " + (ar.waiting != null) + " | Spec: " + (ar.spectator != null));
                Msg.send(p, "&7Tim siap: " + ar.activeTeams() + " | Shop: " + ar.shops.size() + " | Upgrade NPC: " + ar.upgradeShops.size()
                        + " | Diamond: " + ar.diamondGens.size() + " | Emerald: " + ar.emeraldGens.size());
                String v = ar.validate();
                Msg.send(p, v == null ? "&aArena siap diaktifkan (/bw enable)." : "&cBelum siap: " + v);
                return;
            }
            case "enable" -> {
                String v = ar.validate();
                if (v != null) { Msg.send(p, "&c" + v); return; }
                ar.enabled = true;
                mgr.save();
                Msg.send(p, "&aArena diaktifkan! Sekarang muncul di /bw arenas.");
                return;
            }
            case "disable" -> {
                if (!mgr.release(ar)) { Msg.send(p, "&cMasih ada pemain di arena itu."); return; }
                ar.enabled = false;
                mgr.save();
                Msg.send(p, "&eArena dinonaktifkan.");
                return;
            }
            default -> {}
        }

        if (ar.enabled) { Msg.send(p, "&cNonaktifkan arena dulu (/bw disable) sebelum mengedit."); return; }
        Location here = p.getLocation();

        switch (sub) {
            case "setwaiting", "setlobby" -> { ar.waiting = here; Msg.send(p, "&aWaiting lobby diset."); }
            case "setspec" -> { ar.spectator = here; Msg.send(p, "&aSpectator diset."); }
            case "setmode" -> {
                Mode m = a.length < 2 ? null : Mode.parse(a[1]);
                if (m == null) { Msg.send(p, "&cGunakan: /bw setmode <solo|duo|squad|1v1>"); return; }
                ar.mode = m;
                Msg.send(p, "&aMode: &f" + m.display + " &7(" + m.teamSize + " pemain/tim, maks " + m.maxTeams
                        + " tim, kapasitas arena " + ar.maxPlayers() + ")");
            }
            case "setmin" -> {
                Integer n = parse(a, 1);
                if (n == null || n < 2) { Msg.send(p, "&cGunakan: /bw setmin <angka>=2"); return; }
                ar.minPlayers = n;
                Msg.send(p, "&aMinimal pemain: " + n);
            }
            case "setspawn" -> {
                BWTeam t = a.length < 2 ? null : BWTeam.parse(a[1]);
                if (t == null) { Msg.send(p, "&cTim tidak valid. /bw help"); return; }
                ar.spawns.put(t, here);
                Msg.send(p, "&aSpawn tim " + t.legacy() + t.display + " &adiset (generator besi/emas juga di titik ini).");
            }
            case "setbed" -> {
                BWTeam t = a.length < 2 ? null : BWTeam.parse(a[1]);
                if (t == null) { Msg.send(p, "&cTim tidak valid. /bw help"); return; }
                Block b = p.getTargetBlockExact(6);
                if (b == null || !Tag.BEDS.isTagged(b.getType())) { Msg.send(p, "&cArahkan crosshair ke bed (jarak <6 blok)."); return; }
                ar.beds.put(t, b.getLocation());
                Msg.send(p, "&aBed tim " + t.legacy() + t.display + " &adiset.");
            }
            case "addgen" -> {
                String type = a.length < 2 ? "" : a[1].toLowerCase();
                if (type.equals("diamond")) ar.diamondGens.add(here);
                else if (type.equals("emerald")) ar.emeraldGens.add(here);
                else { Msg.send(p, "&cGunakan: /bw addgen <diamond|emerald>"); return; }
                Msg.send(p, "&aGenerator " + type + " ditambahkan.");
            }
            case "addshop" -> { ar.shops.add(here); Msg.send(p, "&aItem shop ditambahkan (" + ar.shops.size() + ")."); }
            case "addupgrade" -> { ar.upgradeShops.add(here); Msg.send(p, "&aNPC Upgrade Tim ditambahkan (" + ar.upgradeShops.size() + ")."); }
            case "clearshops" -> { ar.shops.clear(); ar.upgradeShops.clear(); Msg.send(p, "&eSemua NPC shop dihapus."); }
            default -> { Msg.send(p, "&cSub-perintah tidak dikenal. /bw help"); return; }
        }
        mgr.save();
    }

    private Integer parse(String[] a, int i) {
        if (a.length <= i) return null;
        try { return Integer.parseInt(a[i]); } catch (NumberFormatException e) { return null; }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(PLAYER_SUBS);
            if (s.hasPermission("bedwars.admin")) out.addAll(ADMIN_SUBS);
        } else if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "join", "edit", "delete" -> mgr.all().forEach(x -> out.add(x.name));
                case "setspawn", "setbed" -> { for (BWTeam t : BWTeam.values()) out.add(t.name().toLowerCase()); }
                case "addgen" -> out.addAll(List.of("diamond", "emerald"));
                case "setmode" -> out.addAll(List.of("solo", "duo", "squad", "1v1"));
                default -> {}
            }
        }
        String pre = a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(pre));
        return out;
    }
}
