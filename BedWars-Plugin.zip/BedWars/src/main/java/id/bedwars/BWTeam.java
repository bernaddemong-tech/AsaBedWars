package id.bedwars;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Material;

public enum BWTeam {
    RED("Red", "R", "&c", NamedTextColor.RED, Color.RED, Material.RED_WOOL),
    BLUE("Blue", "B", "&9", NamedTextColor.BLUE, Color.BLUE, Material.BLUE_WOOL),
    GREEN("Green", "G", "&a", NamedTextColor.GREEN, Color.LIME, Material.LIME_WOOL),
    YELLOW("Yellow", "Y", "&e", NamedTextColor.YELLOW, Color.YELLOW, Material.YELLOW_WOOL),
    AQUA("Aqua", "A", "&b", NamedTextColor.AQUA, Color.AQUA, Material.LIGHT_BLUE_WOOL),
    WHITE("White", "W", "&f", NamedTextColor.WHITE, Color.WHITE, Material.WHITE_WOOL),
    PINK("Pink", "P", "&d", NamedTextColor.LIGHT_PURPLE, Color.FUCHSIA, Material.PINK_WOOL),
    GRAY("Gray", "S", "&7", NamedTextColor.GRAY, Color.GRAY, Material.GRAY_WOOL);

    public final String display;
    public final String letter;
    private final String legacy;
    public final NamedTextColor text;
    public final Color color;
    public final Material wool;

    BWTeam(String display, String letter, String legacy, NamedTextColor text, Color color, Material wool) {
        this.display = display;
        this.letter = letter;
        this.legacy = legacy;
        this.text = text;
        this.color = color;
        this.wool = wool;
    }

    public String legacy() { return legacy; }

    public static BWTeam parse(String s) {
        if (s == null) return null;
        for (BWTeam t : values()) {
            if (t.name().equalsIgnoreCase(s) || t.display.equalsIgnoreCase(s)) return t;
        }
        return null;
    }
}
