package id.bedwars;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class BedWarsPlugin extends JavaPlugin implements Listener {
    public NamespacedKey leaveKey;
    public NamespacedKey shopKey;
    private ArenaManager arenas;
    private boolean loaded;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        leaveKey = new NamespacedKey(this, "leave");
        shopKey = new NamespacedKey(this, "shop");
        BedrockUtil.init(getConfig().getString("bedrock-prefix", "."));
        arenas = new ArenaManager(this);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new GameListener(this, arenas), this);

        // Arena dimuat setelah semua dunia (termasuk dunia Multiverse) siap.
        getServer().getScheduler().runTask(this, this::loadArenasOnce);

        PluginCommand cmd = getCommand("bw");
        if (cmd != null) {
            BWCommand h = new BWCommand(this, arenas);
            cmd.setExecutor(h);
            cmd.setTabCompleter(h);
        }
        getLogger().info("BedWars aktif. Floodgate: " + yn("floodgate")
                + " | Multiverse-Core: " + yn("Multiverse-Core")
                + " | Multiverse-Inventories: " + yn("Multiverse-Inventories"));
    }

    private String yn(String plugin) { return getServer().getPluginManager().isPluginEnabled(plugin) ? "ya" : "tidak"; }

    @EventHandler
    public void onServerLoad(ServerLoadEvent e) { loadArenasOnce(); }

    private void loadArenasOnce() {
        if (loaded) return;
        loaded = true;
        arenas.load();
        getLogger().info(arenas.all().size() + " arena dimuat.");
    }

    @Override
    public void onDisable() {
        if (arenas != null) {
            arenas.shutdown();
            arenas.save();
        }
    }

    public boolean mvInventories() {
        return getServer().getPluginManager().isPluginEnabled("Multiverse-Inventories");
    }

    /**
     * Teleport pemain lalu jalankan aksi. Jika pindah dunia dan Multiverse-Inventories aktif,
     * aksi (atur inventory/gamemode) ditunda beberapa tick agar tidak ditimpa MV-Inventories.
     */
    public void teleportThen(Player p, Location dest, Runnable after) {
        World before = p.getWorld();
        p.teleport(dest);
        boolean crossWorld = dest.getWorld() != null && !before.equals(dest.getWorld());
        if (crossWorld && mvInventories() && isEnabled()) {
            long delay = Math.max(1, getConfig().getInt("multiverse.inventory-delay-ticks", 3));
            getServer().getScheduler().runTaskLater(this, after, delay);
        } else {
            after.run();
        }
    }
}
