package id.bedwars;

import org.bukkit.entity.Player;

import java.util.UUID;

/** Deteksi pemain Bedrock (Geyser). Memakai Floodgate lewat reflection (tanpa dependensi wajib). */
public final class BedrockUtil {
    private static String prefix = ".";

    private BedrockUtil() {}

    public static void init(String bedrockPrefix) { prefix = bedrockPrefix == null ? "." : bedrockPrefix; }

    public static boolean isBedrock(Player p) {
        try {
            Class<?> c = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Object api = c.getMethod("getInstance").invoke(null);
            return (boolean) c.getMethod("isFloodgatePlayer", UUID.class).invoke(api, p.getUniqueId());
        } catch (Throwable t) {
            return !prefix.isEmpty() && p.getName().startsWith(prefix);
        }
    }
}
