package id.bedwars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Bed;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Game {
    public enum State { WAITING, STARTING, RUNNING, ENDING }

    private record Saved(ItemStack[] contents, GameMode mode, Location loc, int level, float exp) {}
    private record Hit(UUID attacker, long time) {}
    private record Ev(String label, int at, Runnable action) {}

    private static final double[] FORGE_MULT = {1, 1.5, 2, 2, 3};
    private static final int[] DIAMOND_INT = {30, 23, 15};
    private static final int[] EMERALD_INT = {60, 45, 30};

    private final BedWarsPlugin plugin;
    private final ArenaManager mgr;
    public final Arena arena;

    private State state = State.WAITING;
    private final Map<UUID, BWTeam> teams = new LinkedHashMap<>();
    private final Map<UUID, Saved> saved = new HashMap<>();
    private final Set<UUID> eliminated = new HashSet<>();
    private final Set<UUID> respawning = new HashSet<>();
    private final Set<BWTeam> bedAlive = EnumSet.noneOf(BWTeam.class);
    private final Set<BWTeam> activeTeams = EnumSet.noneOf(BWTeam.class);
    private final Set<Location> placed = new HashSet<>();
    private final Map<Location, BlockData> destroyedBeds = new HashMap<>();
    private final List<Entity> npcs = new ArrayList<>();
    private final Map<UUID, Hit> lastHit = new HashMap<>();
    private final Map<UUID, SidebarBoard> boards = new HashMap<>();
    private final Map<BWTeam, TeamUpgrades> ups = new EnumMap<>(BWTeam.class);
    private final Map<BWTeam, double[]> acc = new EnumMap<>(BWTeam.class);
    private final List<Ev> events = new ArrayList<>();

    private BukkitTask countdownTask, gameTask, endTask;
    private int countdown, elapsed;
    private int diamondTier = 1, emeraldTier = 1, diamondCtr, emeraldCtr;
    private boolean boardErrorLogged;

    public Game(BedWarsPlugin plugin, ArenaManager mgr, Arena arena) {
        this.plugin = plugin;
        this.mgr = mgr;
        this.arena = arena;
    }

    // ---------- accessors ----------
    public State getState() { return state; }
    public int size() { return teams.size(); }
    public BWTeam teamOf(Player p) { return teams.get(p.getUniqueId()); }
    public boolean isSpectating(Player p) { return eliminated.contains(p.getUniqueId()) || respawning.contains(p.getUniqueId()); }
    public boolean isPlaced(Block b) { return placed.contains(b.getLocation()); }
    public void addPlaced(Block b) { placed.add(b.getLocation()); }
    public void removePlaced(Block b) { placed.remove(b.getLocation()); }
    public void recordHit(Player victim, Player attacker) { lastHit.put(victim.getUniqueId(), new Hit(attacker.getUniqueId(), System.currentTimeMillis())); }
    public TeamUpgrades upgrades(BWTeam t) { return ups.computeIfAbsent(t, k -> new TeamUpgrades()); }

    public void broadcast(String legacy) {
        for (UUID id : teams.keySet()) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.sendMessage(Msg.c(Msg.PREFIX + legacy));
        }
    }

    public void broadcastTeam(BWTeam t, String legacy) {
        for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) {
            if (e.getValue() != t) continue;
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null) p.sendMessage(Msg.c(Msg.PREFIX + legacy));
        }
    }

    // ---------- join / leave ----------
    public boolean join(Player p) {
        if (state != State.WAITING && state != State.STARTING) { Msg.send(p, "&cGame sedang berjalan."); return false; }
        if (teams.size() >= arena.maxPlayers()) { Msg.send(p, "&cArena penuh."); return false; }
        UUID id = p.getUniqueId();
        saved.put(id, new Saved(p.getInventory().getContents(), p.getGameMode(), p.getLocation(), p.getLevel(), p.getExp()));
        teams.put(id, pickTeam());
        mgr.bind(id, this);

        plugin.teleportThen(p, arena.waiting, () -> {
            if (!teams.containsKey(id) || !p.isOnline() || state == State.RUNNING) return;
            reset(p, GameMode.ADVENTURE);
            p.getInventory().setItem(8, leaveItem());
        });

        broadcast("&e" + p.getName() + " &7bergabung &8(" + teams.size() + "/" + arena.maxPlayers() + ")");
        if (BedrockUtil.isBedrock(p)) Msg.send(p, "&7Terdeteksi Bedrock. Ketuk item Barrier untuk keluar.");
        if (state == State.WAITING && teams.size() >= Math.max(2, arena.minPlayers)) startCountdown();
        if (state == State.STARTING && teams.size() >= arena.maxPlayers() && countdown > 5) countdown = 5;
        updateBoards(); // scoreboard waiting muncul begitu pemain join
        return true;
    }

    public void leave(Player p) { leave(p, false); }

    public void leave(Player p, boolean quitting) {
        UUID id = p.getUniqueId();
        if (!teams.containsKey(id)) return;
        teams.remove(id);
        eliminated.remove(id);
        respawning.remove(id);
        boards.remove(id);
        restore(p, quitting);
        mgr.unbind(id);
        broadcast("&e" + p.getName() + " &7keluar dari game.");
        switch (state) {
            case RUNNING -> {
                if (teams.isEmpty()) forceStop(); else { checkWin(); updateBoards(); }
            }
            case WAITING, STARTING -> updateBoards();
            default -> {}
        }
    }

    private BWTeam pickTeam() {
        BWTeam best = null;
        int bestCount = Integer.MAX_VALUE;
        for (BWTeam t : arena.usedTeams()) {
            int c = 0;
            for (BWTeam x : teams.values()) if (x == t) c++;
            if (c < arena.mode.teamSize && c < bestCount) { best = t; bestCount = c; }
        }
        return best;
    }

    private ItemStack leaveItem() {
        ItemStack i = Items.named(Material.BARRIER, 1, "&cKeluar &7(klik kanan / ketuk)", null);
        ItemMeta m = i.getItemMeta();
        m.getPersistentDataContainer().set(plugin.leaveKey, PersistentDataType.BYTE, (byte) 1);
        i.setItemMeta(m);
        return i;
    }

    private void reset(Player p, GameMode mode) {
        p.getInventory().clear();
        p.setGameMode(mode);
        p.setHealth(20);
        p.setFoodLevel(20);
        p.setSaturation(20);
        p.setFireTicks(0);
        p.setFallDistance(0);
        p.setLevel(0);
        p.setExp(0);
        for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
    }

    private void restore(Player p, boolean immediate) {
        Saved s = saved.remove(p.getUniqueId());
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        p.displayName(null);
        p.playerListName(null);
        Location dest = s != null ? s.loc() : p.getWorld().getSpawnLocation();
        Runnable apply = () -> {
            reset(p, GameMode.SURVIVAL);
            if (s != null) {
                p.getInventory().setContents(s.contents());
                p.setGameMode(s.mode());
                p.setLevel(s.level());
                p.setExp(s.exp());
            }
        };
        if (immediate) {
            p.teleport(dest);
            apply.run();
        } else {
            plugin.teleportThen(p, dest, apply);
        }
    }

    // ---------- lifecycle ----------
    private void startCountdown() {
        state = State.STARTING;
        countdown = plugin.getConfig().getInt("countdown", 15);
        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (teams.size() < Math.max(2, arena.minPlayers)) {
                countdownTask.cancel();
                state = State.WAITING;
                broadcast("&cPemain kurang, hitung mundur dibatalkan.");
                updateBoards();
                return;
            }
            if (countdown <= 0) { begin(); return; }
            if (countdown <= 5 || countdown % 10 == 0) {
                for (UUID id : teams.keySet()) {
                    Player p = Bukkit.getPlayer(id);
                    if (p == null) continue;
                    p.showTitle(Title.title(Msg.c("&e" + countdown), Msg.c("&7Bersiap..."),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(900), Duration.ZERO)));
                    p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                }
            }
            countdown--;
            updateBoards();
        }, 0L, 20L);
    }

    private void ev(String key, int def, String label, Runnable r) {
        events.add(new Ev(label, plugin.getConfig().getInt("events." + key, def), r));
    }

    private void begin() {
        if (countdownTask != null) countdownTask.cancel();
        state = State.RUNNING;
        elapsed = 0;
        diamondTier = 1; emeraldTier = 1; diamondCtr = 0; emeraldCtr = 0;
        activeTeams.clear();
        activeTeams.addAll(teams.values());
        bedAlive.clear();
        bedAlive.addAll(activeTeams);
        ups.clear();
        acc.clear();

        // hapus bed tim yang tidak dipakai / kosong
        for (BWTeam t : arena.activeTeams()) {
            if (activeTeams.contains(t)) continue;
            Location bl = arena.beds.get(t);
            if (bl != null) removeBed(bl.getBlock());
        }

        // jadwal event
        events.clear();
        ev("diamond-2", 360, "Diamond Upgrade II", () -> { diamondTier = 2; broadcast("&bGenerator Diamond naik ke tier &lII&b!"); });
        ev("emerald-2", 720, "Emerald Upgrade II", () -> { emeraldTier = 2; broadcast("&aGenerator Emerald naik ke tier &lII&a!"); });
        ev("diamond-3", 1080, "Diamond Upgrade III", () -> { diamondTier = 3; broadcast("&bGenerator Diamond naik ke tier &lIII&b!"); });
        ev("emerald-3", 1440, "Emerald Upgrade III", () -> { emeraldTier = 3; broadcast("&aGenerator Emerald naik ke tier &lIII&a!"); });
        ev("bed-gone", 1800, "Bed Gone", this::bedGone);
        ev("game-end", 2700, "Game End", () -> end(null));
        events.sort(Comparator.comparingInt(Ev::at));

        for (UUID id : new ArrayList<>(teams.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) spawnPlayer(p);
        }
        for (Location l : arena.shops) spawnNpc(l, "&6&lITEM SHOP", (byte) 1);
        for (Location l : arena.upgradeShops) spawnNpc(l, "&b&lUPGRADE TIM", (byte) 2);

        broadcast("&a&lGame dimulai! &7Hancurkan bed lawan & jadilah yang terakhir bertahan.");
        gameTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
        updateBoards();
    }

    private void spawnNpc(Location l, String name, byte kind) {
        Villager v = l.getWorld().spawn(l, Villager.class, vv -> {
            vv.setAI(false);
            vv.setInvulnerable(true);
            vv.setSilent(true);
            vv.setPersistent(false);
            vv.customName(Msg.c(name));
            vv.setCustomNameVisible(true);
            vv.getPersistentDataContainer().set(plugin.shopKey, PersistentDataType.BYTE, kind);
        });
        npcs.add(v);
    }

    private void tick() {
        elapsed++;
        for (Ev e : new ArrayList<>(events)) if (e.at() == elapsed) e.action().run();
        if (state != State.RUNNING) return;

        // generator tim (dipengaruhi Forge)
        for (BWTeam t : activeTeams) {
            Location sp = arena.spawns.get(t);
            if (sp == null) continue;
            TeamUpgrades u = upgrades(t);
            double[] a = acc.computeIfAbsent(t, k -> new double[3]);
            double m = FORGE_MULT[u.forge];
            a[0] += 0.5 * m;
            a[1] += m / 6.0;
            if (u.forge >= 3) a[2] += u.forge == 3 ? 0.1 : 0.15;
            while (a[0] >= 1) { drop(sp, Material.IRON_INGOT); a[0]--; }
            while (a[1] >= 1) { drop(sp, Material.GOLD_INGOT); a[1]--; }
            while (a[2] >= 1) { drop(sp, Material.EMERALD); a[2]--; }
        }
        // generator global
        if (++diamondCtr >= DIAMOND_INT[diamondTier - 1]) {
            diamondCtr = 0;
            for (Location l : arena.diamondGens) drop(l, Material.DIAMOND);
        }
        if (++emeraldCtr >= EMERALD_INT[emeraldTier - 1]) {
            emeraldCtr = 0;
            for (Location l : arena.emeraldGens) drop(l, Material.EMERALD);
        }
        // heal pool
        for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) {
            if (!upgrades(e.getValue()).heal || eliminated.contains(e.getKey()) || respawning.contains(e.getKey())) continue;
            Player p = Bukkit.getPlayer(e.getKey());
            Location sp = arena.spawns.get(e.getValue());
            if (p == null || sp == null || !p.getWorld().equals(sp.getWorld())) continue;
            if (p.getLocation().distanceSquared(sp) <= 225) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 60, 0, true, false, true));
            }
        }
        updateBoards();
    }

    private void drop(Location l, Material m) {
        Location at = l.clone().add(0, 0.5, 0);
        at.getWorld().dropItem(at, new ItemStack(m), it -> it.setVelocity(new Vector(0, 0, 0)));
    }

    private void bedGone() {
        for (BWTeam t : new ArrayList<>(bedAlive)) {
            Location bl = arena.beds.get(t);
            if (bl != null) removeBed(bl.getBlock());
        }
        bedAlive.clear();
        for (UUID id : teams.keySet()) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            p.showTitle(Title.title(Msg.c("&c&lBED GONE"), Msg.c("&7Semua bed telah hancur!"),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofSeconds(3), Duration.ofMillis(500))));
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
        }
        broadcast("&c&lSemua bed hancur! &7Tidak ada respawn lagi.");
        updateBoards();
    }

    private void spawnPlayer(Player p) {
        UUID id = p.getUniqueId();
        respawning.remove(id);
        BWTeam t = teams.get(id);
        if (t == null) return;
        plugin.teleportThen(p, arena.spawns.get(t), () -> {
            if (!teams.containsKey(id) || !p.isOnline()) return;
            reset(p, GameMode.SURVIVAL);
            PlayerInventory inv = p.getInventory();
            // armor kulit berwarna sesuai tim
            inv.setHelmet(Items.leather(Material.LEATHER_HELMET, t));
            inv.setChestplate(Items.leather(Material.LEATHER_CHESTPLATE, t));
            inv.setLeggings(Items.leather(Material.LEATHER_LEGGINGS, t));
            inv.setBoots(Items.leather(Material.LEATHER_BOOTS, t));
            inv.addItem(Items.unbreakable(new ItemStack(Material.WOODEN_SWORD)));
            p.displayName(Component.text(p.getName(), t.text));
            p.playerListName(Component.text(t.letter + " " + p.getName(), t.text));
            applyUpgrades(p);
            updateBoards();
        });
    }

    // ---------- upgrades ----------
    public void applyUpgrades(Player p) {
        BWTeam t = teams.get(p.getUniqueId());
        if (t == null) return;
        TeamUpgrades u = upgrades(t);
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (it != null && it.getType().name().endsWith("_SWORD")) {
                if (u.sharp) it.addUnsafeEnchantment(Enchantment.SHARPNESS, 1);
                inv.setItem(i, it);
            }
        }
        ItemStack[] armor = inv.getArmorContents();
        for (ItemStack it : armor) {
            if (it == null) continue;
            if (u.armor > 0) it.addUnsafeEnchantment(Enchantment.PROTECTION, u.armor);
            else it.removeEnchantment(Enchantment.PROTECTION);
        }
        inv.setArmorContents(armor);
        p.removePotionEffect(PotionEffectType.HASTE);
        if (u.haste > 0) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, PotionEffect.INFINITE_DURATION, u.haste - 1, false, false, true));
        }
    }

    public void onUpgrade(Player buyer, BWTeam t, String what) {
        for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) {
            if (e.getValue() != t) continue;
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null) {
                applyUpgrades(p);
                p.sendMessage(Msg.c(Msg.PREFIX + "&a" + buyer.getName() + " &7membeli &b" + what + "&7!"));
            }
        }
    }

    // ---------- bed & death ----------
    private Block recordBed(Block b) {
        if (!(b.getBlockData() instanceof Bed bd)) return null;
        Block other = bd.getPart() == Bed.Part.HEAD
                ? b.getRelative(bd.getFacing().getOppositeFace())
                : b.getRelative(bd.getFacing());
        destroyedBeds.putIfAbsent(b.getLocation(), bd);
        if (other.getBlockData() instanceof Bed od) destroyedBeds.putIfAbsent(other.getLocation(), od);
        return other;
    }

    private void removeBed(Block b) {
        Block other = recordBed(b);
        b.setType(Material.AIR, false);
        if (other != null) other.setType(Material.AIR, false);
    }

    /** @return true jika boleh dihancurkan. */
    public boolean onBedBreak(Player p, Block b) {
        BWTeam owner = null;
        for (Map.Entry<BWTeam, Location> en : arena.beds.entrySet()) {
            Location bl = en.getValue();
            if (bl.getWorld().equals(b.getWorld())
                    && bl.getBlock().getLocation().distanceSquared(b.getLocation()) <= 1.01) owner = en.getKey();
        }
        if (owner == null) return false;
        BWTeam mine = teams.get(p.getUniqueId());
        if (owner == mine) {
            Msg.send(p, "&cKamu tidak bisa menghancurkan bed timmu sendiri!");
            return false;
        }
        recordBed(b);
        if (bedAlive.remove(owner)) {
            broadcast("&7Bed " + owner.legacy() + owner.display + " &7dihancurkan oleh " + mine.legacy() + p.getName() + "&7!");
            for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) {
                if (e.getValue() != owner) continue;
                Player v = Bukkit.getPlayer(e.getKey());
                if (v == null) continue;
                v.showTitle(Title.title(Msg.c("&c&lBED HANCUR!"), Msg.c("&eKamu tidak akan respawn lagi"),
                        Title.Times.times(Duration.ofMillis(100), Duration.ofSeconds(3), Duration.ofMillis(500))));
                v.playSound(v.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
            }
            updateBoards();
        }
        return true;
    }

    private boolean isResource(Material m) {
        return m == Material.IRON_INGOT || m == Material.GOLD_INGOT || m == Material.DIAMOND || m == Material.EMERALD;
    }

    public void handleDeath(Player p, Player killer) {
        UUID id = p.getUniqueId();
        BWTeam t = teams.get(id);
        if (t == null || state != State.RUNNING) return;
        if (killer == null) {
            Hit h = lastHit.get(id);
            if (h != null && System.currentTimeMillis() - h.time() < 8000) killer = Bukkit.getPlayer(h.attacker());
        }
        if (killer != null && (killer.equals(p) || !teams.containsKey(killer.getUniqueId()) || isSpectating(killer))) killer = null;

        boolean finalKill = !bedAlive.contains(t);
        String msg;
        if (killer != null) {
            BWTeam kt = teams.get(killer.getUniqueId());
            msg = t.legacy() + p.getName() + " &7dibunuh oleh " + kt.legacy() + killer.getName();
            for (ItemStack s : p.getInventory().getContents()) {
                if (s != null && isResource(s.getType())) {
                    Map<Integer, ItemStack> left = killer.getInventory().addItem(s.clone());
                    for (ItemStack r : left.values()) killer.getWorld().dropItem(killer.getLocation(), r);
                }
            }
            killer.playSound(killer.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        } else {
            msg = t.legacy() + p.getName() + " &7mati.";
        }
        broadcast(msg + (finalKill ? " &b&lFINAL KILL" : ""));

        p.getInventory().clear();
        p.setFireTicks(0);
        p.setFallDistance(0);
        for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
        lastHit.remove(id);

        if (finalKill) eliminate(p); else startRespawn(p, t);
    }

    private void startRespawn(Player p, BWTeam t) {
        UUID id = p.getUniqueId();
        respawning.add(id);
        p.setHealth(20);
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(arena.spawns.get(t).clone().add(0, 8, 0));
        int secs = plugin.getConfig().getInt("respawn-seconds", 5);
        new BukkitRunnable() {
            int s = secs;
            @Override
            public void run() {
                if (state != State.RUNNING || !teams.containsKey(id) || !p.isOnline()) { cancel(); return; }
                if (s <= 0) {
                    cancel();
                    if (bedAlive.contains(t)) spawnPlayer(p); else eliminate(p);
                    return;
                }
                p.showTitle(Title.title(Msg.c("&cKamu mati!"), Msg.c("&eRespawn dalam " + s + " detik"),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(1200), Duration.ZERO)));
                s--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void eliminate(Player p) {
        UUID id = p.getUniqueId();
        respawning.remove(id);
        eliminated.add(id);
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(arena.spectator);
        p.showTitle(Title.title(Msg.c("&c&lTERELIMINASI"), Msg.c("&7Kamu menonton sekarang"),
                Title.Times.times(Duration.ofMillis(100), Duration.ofSeconds(3), Duration.ofMillis(500))));
        updateBoards();
        checkWin();
    }

    private void checkWin() {
        if (state != State.RUNNING) return;
        Set<BWTeam> alive = EnumSet.noneOf(BWTeam.class);
        for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) if (!eliminated.contains(e.getKey())) alive.add(e.getValue());
        if (alive.size() <= 1) end(alive.isEmpty() ? null : alive.iterator().next());
    }

    private void end(BWTeam winner) {
        if (state == State.ENDING) return;
        state = State.ENDING;
        if (gameTask != null) gameTask.cancel();
        if (winner != null) broadcast("&6&lTIM " + winner.legacy() + winner.display.toUpperCase() + " &6&lMENANG!");
        else broadcast("&7Game berakhir seri.");
        for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null) continue;
            boolean won = e.getValue() == winner;
            p.showTitle(Title.title(Msg.c(won ? "&6&lMENANG!" : "&c&lGAME SELESAI"),
                    Msg.c(winner == null ? "&7Seri" : "&7Pemenang: " + winner.legacy() + winner.display),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(5), Duration.ofSeconds(1))));
            p.playSound(p.getLocation(), won ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_WITHER_DEATH, 1f, 1f);
        }
        updateBoards();
        endTask = Bukkit.getScheduler().runTaskLater(plugin, this::cleanup, 20L * 8);
    }

    public void forceStop() { cleanup(); }

    private void cancelTasks() {
        if (countdownTask != null) countdownTask.cancel();
        if (gameTask != null) gameTask.cancel();
        if (endTask != null) endTask.cancel();
    }

    private void cleanup() {
        cancelTasks();
        for (UUID id : new ArrayList<>(teams.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) restore(p, !plugin.isEnabled());
            mgr.unbind(id);
        }
        teams.clear();
        saved.clear();
        eliminated.clear();
        respawning.clear();
        bedAlive.clear();
        activeTeams.clear();
        lastHit.clear();
        boards.clear();
        ups.clear();
        acc.clear();
        events.clear();
        restoreWorld();
        state = State.WAITING;
    }

    private void restoreWorld() {
        for (Location l : placed) l.getBlock().setType(Material.AIR, false);
        placed.clear();
        for (Map.Entry<Location, BlockData> e : destroyedBeds.entrySet()) e.getKey().getBlock().setBlockData(e.getValue(), false);
        destroyedBeds.clear();
        for (Entity e : npcs) e.remove();
        npcs.clear();
        Location c = null;
        for (Location l : arena.spawns.values()) { c = l; break; }
        if (c != null && c.getWorld() != null) {
            for (Entity e : c.getWorld().getNearbyEntities(c, 200, 200, 200,
                    en -> en instanceof org.bukkit.entity.Item || en instanceof TNTPrimed
                            || en instanceof Arrow || en instanceof org.bukkit.entity.Fireball)) e.remove();
        }
    }

    // ---------- scoreboard ----------
    private String titleFor() {
        boolean inGame = state == State.RUNNING || state == State.ENDING;
        return plugin.getConfig().getString(inGame ? "scoreboard.title-ingame" : "scoreboard.title-waiting",
                inGame ? "&e&lBEDWARS" : "&e&lWAITING FOR PLAYER");
    }

    private String fmt(int secs) { return String.format("%02d:%02d", secs / 60, secs % 60); }

    public void updateBoards() {
        Map<String, BWTeam> names = new HashMap<>();
        if (state == State.RUNNING || state == State.ENDING) {
            for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) {
                Player p = Bukkit.getPlayer(e.getKey());
                if (p != null) names.put(p.getName(), e.getValue());
            }
        }
        for (UUID id : teams.keySet()) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            try {
                SidebarBoard b = boards.get(id);
                boolean fresh = b == null;
                if (fresh) {
                    b = new SidebarBoard(titleFor(), plugin.getConfig().getBoolean("scoreboard.hide-numbers", true));
                    boards.put(id, b);
                }
                b.title(titleFor());
                b.set(lines(p));
                if (plugin.getConfig().getBoolean("scoreboard.nametag-colors", true)) b.nameTeams(names);
                if (fresh) p.setScoreboard(b.scoreboard()); // kirim setelah terisi penuh
            } catch (Throwable ex) {
                if (!boardErrorLogged) {
                    boardErrorLogged = true;
                    plugin.getLogger().log(java.util.logging.Level.SEVERE, "Gagal merender scoreboard untuk " + p.getName(), ex);
                }
            }
        }
    }

    private List<String> lines(Player p) {
        List<String> l = new ArrayList<>();
        String domain = "&e" + plugin.getConfig().getString("server-domain", "asamc.my.id");
        String date = "&7" + LocalDate.now().format(DateTimeFormatter.ofPattern("MM/dd/yy")) + " &8" + arena.mapName();
        BWTeam mine = teams.get(p.getUniqueId());
        l.add(date);
        l.add("");
        if (state == State.RUNNING || state == State.ENDING) {
            Ev next = null;
            for (Ev e : events) if (e.at() > elapsed) { next = e; break; }
            l.add(next == null ? "&7-" : "&f" + next.label() + " &7in &a" + fmt(next.at() - elapsed));
            l.add("");
            String alive = plugin.getConfig().getString("scoreboard.bed-alive", "&a√");
            String dead = plugin.getConfig().getString("scoreboard.eliminated", "&cX");
            for (BWTeam t : activeTeams) {
                int n = 0;
                for (Map.Entry<UUID, BWTeam> e : teams.entrySet()) if (e.getValue() == t && !eliminated.contains(e.getKey())) n++;
                String status = bedAlive.contains(t) ? alive : (n > 0 ? "&e" + n : dead);
                l.add(t.legacy() + t.letter + " &f" + t.display + "&7: " + status + (t == mine ? " &7YOU" : ""));
            }
        } else {
            l.add("&fMap: &a" + arena.mapName());
            l.add("&fPlayers: &a" + teams.size() + "/" + arena.maxPlayers());
            l.add("");
            l.add(state == State.STARTING ? "&fStarting in &a" + Math.max(countdown, 0) + "s" : "&7Waiting for players...");
            l.add("");
            l.add("&fMode: &a" + arena.mode.display);
            if (mine != null) l.add("&fTeam: " + mine.legacy() + mine.display);
        }
        l.add("");
        l.add(domain);
        return l;
    }
}
