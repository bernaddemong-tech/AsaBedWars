package id.bedwars;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class GameListener implements Listener {
    private final BedWarsPlugin plugin;
    private final ArenaManager mgr;
    private final Map<UUID, Long> fireballCooldown = new HashMap<>();

    public GameListener(BedWarsPlugin plugin, ArenaManager mgr) {
        this.plugin = plugin;
        this.mgr = mgr;
    }

    // ---------- blocks ----------
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g == null) return;
        if (g.getState() != Game.State.RUNNING || g.isSpectating(p)) { e.setCancelled(true); return; }
        Block b = e.getBlock();
        if (Tag.BEDS.isTagged(b.getType())) {
            e.setDropItems(false);
            if (!g.onBedBreak(p, b)) e.setCancelled(true);
            return;
        }
        if (!g.isPlaced(b)) {
            e.setCancelled(true);
            Msg.send(p, "&cHanya blok buatan pemain yang bisa dihancurkan.");
        } else {
            g.removePlaced(b);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g == null) return;
        if (g.getState() != Game.State.RUNNING || g.isSpectating(p)) { e.setCancelled(true); return; }
        Block b = e.getBlock();
        if (b.getType() == Material.TNT) {
            b.setType(Material.AIR);
            Location l = b.getLocation().add(0.5, 0, 0.5);
            b.getWorld().spawn(l, TNTPrimed.class, t -> {
                t.setFuseTicks(40);
                t.setSource(p);
            });
            return;
        }
        g.addPlaced(b);
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        List<Game> running = mgr.runningGames();
        if (running.isEmpty()) return;
        boolean inGameWorld = false;
        for (Game g : running) {
            Location sp = g.arena.spawns.values().stream().findFirst().orElse(null);
            if (sp != null && sp.getWorld().equals(e.getLocation().getWorld())) inGameWorld = true;
        }
        if (!inGameWorld) return;
        e.blockList().removeIf(b -> {
            if (b.getType().name().endsWith("GLASS")) return true; // kaca tahan ledak
            for (Game g : running) if (g.isPlaced(b)) return false;
            return true;
        });
    }

    // ---------- fireball ----------
    private void launchFireball(Player p, Game g) {
        if (g.getState() != Game.State.RUNNING || g.isSpectating(p)) return;
        long now = System.currentTimeMillis();
        Long last = fireballCooldown.get(p.getUniqueId());
        if (last != null && now - last < 500) return;
        fireballCooldown.put(p.getUniqueId(), now);

        ItemStack hand = p.getInventory().getItemInMainHand();
        hand.setAmount(hand.getAmount() - 1);
        p.getInventory().setItemInMainHand(hand.getAmount() <= 0 ? null : hand);

        Fireball fb = p.launchProjectile(Fireball.class, p.getEyeLocation().getDirection());
        fb.setShooter(p);
        fb.setYield(2.0f);
        fb.setIsIncendiary(false);
    }

    // ---------- damage / death ----------
    private Player attacker(EntityDamageEvent e) {
        if (!(e instanceof EntityDamageByEntityEvent ee)) return null;
        Entity d = ee.getDamager();
        if (d instanceof Player pl) return pl;
        if (d instanceof Projectile pr && pr.getShooter() instanceof Player pl) return pl; // termasuk Fireball
        if (d instanceof TNTPrimed t && t.getSource() instanceof Player pl) return pl;
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Game g = mgr.gameOf(p);
        if (g == null) return;
        boolean isVoid = e.getCause() == EntityDamageEvent.DamageCause.VOID;

        if (g.getState() != Game.State.RUNNING) {
            e.setCancelled(true);
            if (isVoid) p.teleport(g.getState() == Game.State.ENDING ? g.arena.spectator : g.arena.waiting);
            return;
        }
        if (g.isSpectating(p)) {
            e.setCancelled(true);
            if (isVoid) p.teleport(g.arena.spectator);
            return;
        }
        Player atk = attacker(e);
        if (atk != null && !atk.equals(p)) {
            Game ag = mgr.gameOf(atk);
            if (ag == g) {
                if (g.teamOf(atk) == g.teamOf(p) || g.isSpectating(atk)) { e.setCancelled(true); return; }
                g.recordHit(p, atk);
            }
        }
        // damage ledakan fireball dikurangi (gaya Hypixel)
        if (e.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                && e instanceof EntityDamageByEntityEvent ee && ee.getDamager() instanceof Fireball) {
            e.setDamage(Math.min(e.getDamage(), 3.0));
        }
        if (isVoid || p.getHealth() - e.getFinalDamage() <= 0) {
            e.setCancelled(true);
            g.handleDeath(p, atk);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && mgr.gameOf(p) != null) e.setCancelled(true);
    }

    // ---------- items / interaction ----------
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null) return;
        Player p = e.getPlayer();
        if (it.getType() == Material.FIRE_CHARGE) {
            Game g = mgr.gameOf(p);
            if (g != null) {
                e.setCancelled(true);
                launchFireball(p, g);
            }
            return;
        }
        if (!it.hasItemMeta()) return;
        if (it.getItemMeta().getPersistentDataContainer().has(plugin.leaveKey, PersistentDataType.BYTE)) {
            e.setCancelled(true);
            Game g = mgr.gameOf(p);
            if (g != null) g.leave(p);
        }
    }

    @EventHandler
    public void onNpc(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Byte kind = e.getRightClicked().getPersistentDataContainer().get(plugin.shopKey, PersistentDataType.BYTE);
        if (kind == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g == null || g.getState() != Game.State.RUNNING || g.isSpectating(p)) return;
        if (kind == 2) UpgradeGUI.open(p, g); else ShopGUI.open(p);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        Game g = mgr.gameOf(e.getPlayer());
        if (g != null && g.getState() != Game.State.RUNNING) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryHolder h = e.getInventory().getHolder();
        boolean top = e.getClickedInventory() != null && e.getClickedInventory().equals(e.getInventory());
        if (h instanceof ShopGUI) {
            e.setCancelled(true);
            Game g = mgr.gameOf(p);
            if (top && g != null && g.getState() == Game.State.RUNNING && !g.isSpectating(p)) ShopGUI.buy(p, g, e.getSlot());
            return;
        }
        if (h instanceof UpgradeGUI ug) {
            e.setCancelled(true);
            Game g = mgr.gameOf(p);
            if (top && g != null && g.getState() == Game.State.RUNNING && !g.isSpectating(p)) ug.click(p, e.getSlot());
            return;
        }
        if (h instanceof ArenaMenu m) {
            e.setCancelled(true);
            if (top) {
                String name = m.nameAt(e.getSlot());
                if (name != null) {
                    p.closeInventory();
                    mgr.join(p, name); // -> teleport ke waiting lobby + scoreboard muncul
                }
            }
            return;
        }
        Game g = mgr.gameOf(p);
        if (g != null && g.getState() != Game.State.RUNNING) e.setCancelled(true);
    }

    // ---------- chat / commands / quit ----------
    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        Game g = mgr.gameOf(p);
        if (g == null) {
            e.viewers().removeIf(a -> a instanceof Player v && mgr.gameOf(v) != null);
            return;
        }
        e.viewers().removeIf(a -> !(a instanceof Player v) || mgr.gameOf(v) != g);
        BWTeam t = g.teamOf(p);
        if (t == null) return;
        e.renderer(ChatRenderer.viewerUnaware((src, name, msg) ->
                Msg.c(t.legacy() + "[" + t.display + "] ")
                        .append(Component.text(src.getName(), t.text))
                        .append(Component.text(": ", net.kyori.adventure.text.format.NamedTextColor.WHITE))
                        .append(msg)));
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (mgr.gameOf(p) == null || p.hasPermission("bedwars.admin")) return;
        String m = e.getMessage().toLowerCase();
        if (m.startsWith("/bw") || m.startsWith("/bedwars")) return;
        e.setCancelled(true);
        Msg.send(p, "&cPerintah dinonaktifkan selama bermain. Gunakan /bw leave.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        fireballCooldown.remove(e.getPlayer().getUniqueId());
        Game g = mgr.gameOf(e.getPlayer());
        if (g != null) g.leave(e.getPlayer(), true);
    }
}
