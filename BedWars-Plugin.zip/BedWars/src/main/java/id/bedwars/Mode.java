package id.bedwars;

/** Mode permainan: jumlah pemain per tim dan jumlah tim maksimum. */
public enum Mode {
    SOLO("Solo", 1, 8),    // 8 tim x 1 = 8 pemain
    DUO("Duo", 2, 8),      // 8 tim x 2 = 16 pemain
    SQUAD("Squad", 4, 4),  // 4 tim x 4 = 16 pemain
    DUEL("1v1", 1, 2);     // 2 tim x 1 = 2 pemain

    public final String display;
    public final int teamSize;
    public final int maxTeams;

    Mode(String display, int teamSize, int maxTeams) {
        this.display = display;
        this.teamSize = teamSize;
        this.maxTeams = maxTeams;
    }

    public static Mode parse(String s) {
        if (s == null) return null;
        switch (s.toLowerCase().replace(" ", "")) {
            case "solo": return SOLO;
            case "duo": case "doubles": return DUO;
            case "squad": case "quad": return SQUAD;
            case "1v1": case "1vs1": case "duel": return DUEL;
            default: return null;
        }
    }
}
