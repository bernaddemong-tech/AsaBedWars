package id.bedwars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;

public final class Msg {
    public static final String PREFIX = "&6[BedWars] &r";
    private static final LegacyComponentSerializer S = LegacyComponentSerializer.legacyAmpersand();

    private Msg() {}

    public static Component c(String s) { return S.deserialize(s); }

    public static Component item(String s) {
        return S.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public static void send(CommandSender to, String s) { to.sendMessage(c(PREFIX + s)); }
}
