package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Map;

/** Item shop berbasis chest GUI: kompatibel penuh dengan Bedrock (Geyser). */
public class ShopGUI implements InventoryHolder {
    public record Entry(Material icon, int amount, Material currency, int cost, String name) {}

    public static final int UPGRADE_SLOT = 26;

    private static final Material I = Material.IRON_INGOT, G = Material.GOLD_INGOT, E = Material.EMERALD;

    public static final List<Entry> ITEMS = List.of(
            new Entry(Material.WHITE_WOOL, 16, I, 4, "Wool"),
            new Entry(Material.OAK_PLANKS, 16, G, 4, "Kayu"),
            new Entry(Material.END_STONE, 12, I, 24, "End Stone"),
            new Entry(Material.GLASS, 4, I, 12, "Kaca Tahan Ledak"),
            new Entry(Material.STONE_SWORD, 1, I, 10, "Pedang Batu"),
            new Entry(Material.IRON_SWORD, 1, G, 7, "Pedang Besi"),
            new Entry(Material.DIAMOND_SWORD, 1, E, 4, "Pedang Diamond"),
            new Entry(Material.CHAINMAIL_BOOTS, 1, I, 40, "Armor Rantai"),
            new Entry(Material.IRON_BOOTS, 1, G, 12, "Armor Besi"),
            new Entry(Material.DIAMOND_BOOTS, 1, E, 6, "Armor Diamond"),
            new Entry(Material.BOW, 1, G, 12, "Busur"),
            new Entry(Material.ARROW, 8, G, 2, "Panah"),
            new Entry(Material.SHEARS, 1, I, 20, "Gunting"),
            new Entry(Material.IRON_PICKAXE, 1, I, 10, "Beliung Besi"),
            new Entry(Material.GOLDEN_APPLE, 1, G, 3, "Apel Emas"),
            new Entry(Material.TNT, 1, G, 4, "TNT"),
            new Entry(Material.FIRE_CHARGE, 1, I, 40, "Fireball"),
            new Entry(Material.ENDER_PEARL, 1, E, 4, "Ender Pearl"),
            new Entry(Material.WATER_BUCKET, 1, G, 3, "Ember Air")
    );

    private final Inventory inv;

    private ShopGUI() {
        inv = Bukkit.createInventory(this, 27, Msg.c("&6&lItem Shop"));
        for (int i = 0; i < ITEMS.size(); i++) {
            Entry it = ITEMS.get(i);
            inv.setItem(i, Items.named(it.icon(), it.amount(), "&f" + it.name(),
                    List.of("&7Harga: &e" + it.cost() + " " + currencyName(it.currency()), "&8Ketuk untuk membeli")));
        }
        inv.setItem(UPGRADE_SLOT, Items.named(Material.NETHER_STAR, 1, "&b&lUpgrade Tim",
                List.of("&7Sharpness, Protection, Haste,", "&7Forge, Heal Pool", "&8Ketuk untuk membuka")));
    }

    @Override
    public Inventory getInventory() { return inv; }

    public static void open(Player p) { p.openInventory(new ShopGUI().inv); }

    static String currencyName(Material m) {
        return switch (m) {
            case IRON_INGOT -> "Besi";
            case GOLD_INGOT -> "Emas";
            case DIAMOND -> "Diamond";
            case EMERALD -> "Emerald";
            default -> m.name();
        };
    }

    public static void buy(Player p, Game g, int slot) {
        if (slot == UPGRADE_SLOT) {
            Bukkit.getScheduler().runTask(JavaPlugin.getPlugin(BedWarsPlugin.class), () -> UpgradeGUI.open(p, g));
            return;
        }
        if (slot < 0 || slot >= ITEMS.size()) return;
        Entry it = ITEMS.get(slot);
        BWTeam team = g.teamOf(p);
        if (team == null) return;
        if (!p.getInventory().containsAtLeast(new ItemStack(it.currency()), it.cost())) {
            Msg.send(p, "&cKamu butuh " + it.cost() + " " + currencyName(it.currency()) + ".");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        p.getInventory().removeItem(new ItemStack(it.currency(), it.cost()));

        Material mat = it.icon() == Material.WHITE_WOOL ? team.wool : it.icon();
        String n = mat.name();
        if (n.endsWith("_BOOTS")) {
            Material legs = Material.valueOf(n.replace("_BOOTS", "_LEGGINGS"));
            p.getInventory().setBoots(Items.unbreakable(new ItemStack(mat)));
            p.getInventory().setLeggings(Items.unbreakable(new ItemStack(legs)));
        } else {
            ItemStack stack = new ItemStack(mat, it.amount());
            if (mat == Material.FIRE_CHARGE) {
                stack = Items.named(Material.FIRE_CHARGE, 1, "&cFireball", List.of("&7Klik kanan untuk meluncurkan"));
            } else if (n.endsWith("_SWORD") || n.endsWith("_PICKAXE") || mat == Material.SHEARS || mat == Material.BOW) {
                Items.unbreakable(stack);
            }
            if (n.endsWith("_SWORD")) p.getInventory().remove(Material.WOODEN_SWORD);
            Map<Integer, ItemStack> left = p.getInventory().addItem(stack);
            for (ItemStack r : left.values()) p.getWorld().dropItem(p.getLocation(), r);
        }
        g.applyUpgrades(p); // sharpness / protection tim ikut terpasang
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
    }
}
