package id.bedwars;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/**
 * Sidebar paling kompatibel (Java + Bedrock/Geyser): tiap baris = entry skor biasa,
 * hanya baris yang berubah yang dikirim ulang (hemat paket, tanpa kedip).
 */
public class SidebarBoard {
    private final Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
    private final Objective obj;
    private final String[] shown = new String[15];
    private final int[] shownScore = new int[15];
    private String shownTitle;
    private Map<String, BWTeam> lastNames = new HashMap<>();

    public SidebarBoard(String title, boolean hideNumbers) {
        obj = sb.registerNewObjective("bw", Criteria.DUMMY, Msg.c(title));
        shownTitle = title;
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        if (hideNumbers) {
            try { obj.numberFormat(NumberFormat.blank()); } catch (Throwable ignored) { }
        }
    }

    public Scoreboard scoreboard() { return sb; }

    public void title(String t) {
        if (t.equals(shownTitle)) return;
        shownTitle = t;
        obj.displayName(Msg.c(t));
    }

    /** Entry unik per baris (akhiran kode warna tak terlihat), maksimal 40 karakter. */
    private static String entry(String line, int i) {
        String s = line.replace('&', '\u00a7');
        String suffix = "\u00a7" + Integer.toHexString(i);
        int max = 40 - suffix.length();
        if (s.length() > max) {
            s = s.substring(0, max);
            if (s.endsWith("\u00a7")) s = s.substring(0, s.length() - 1);
        }
        return s + suffix;
    }

    public void set(List<String> content) {
        int n = Math.min(content.size(), 15);
        String[] next = new String[15];
        for (int i = 0; i < n; i++) next[i] = entry(content.get(i), i);

        for (int i = 0; i < 15; i++) {
            if (shown[i] != null && !shown[i].equals(next[i])) sb.resetScores(shown[i]);
        }
        for (int i = 0; i < n; i++) {
            int score = n - i;
            if (!next[i].equals(shown[i]) || shownScore[i] != score) {
                obj.getScore(next[i]).setScore(score);
                shownScore[i] = score;
            }
        }
        System.arraycopy(next, 0, shown, 0, 15);
    }

    /** nama pemain -> tim. Hanya mengirim perubahan; tim dibuat seperlunya. */
    public void nameTeams(Map<String, BWTeam> byName) {
        if (byName.equals(lastNames)) return;
        lastNames = new HashMap<>(byName);
        for (BWTeam t : BWTeam.values()) {
            Team st = sb.getTeam("bw_" + t.name());
            if (st == null) {
                if (!byName.containsValue(t)) continue;
                st = sb.registerNewTeam("bw_" + t.name());
                st.color(t.text);
                st.prefix(Component.text(t.letter + " ", t.text));
            }
            for (String en : new HashSet<>(st.getEntries())) {
                if (byName.get(en) != t) st.removeEntry(en);
            }
        }
        for (Map.Entry<String, BWTeam> e : byName.entrySet()) {
            Team st = sb.getTeam("bw_" + e.getValue().name());
            if (st != null && !st.hasEntry(e.getKey())) st.addEntry(e.getKey());
        }
    }
}
