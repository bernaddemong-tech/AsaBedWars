package id.bedwars;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

/** Scoreboard sidebar tanpa kedip (teknik team-prefix) + warna nametag tim. */
public class SidebarBoard {
    private final Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
    private final Objective obj;
    private int lines = 0;

    public SidebarBoard(String title) {
        obj = sb.registerNewObjective("bw", Criteria.DUMMY, Msg.c(title));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.numberFormat(NumberFormat.blank()); // sembunyikan angka merah di kanan
    }

    public Scoreboard scoreboard() { return sb; }

    public void title(String t) { obj.displayName(Msg.c(t)); }

    private String entry(int i) { return "\u00a7" + Integer.toHexString(i) + "\u00a7r"; }

    public void set(List<String> content) {
        int n = Math.min(content.size(), 15);
        for (int i = 0; i < n; i++) {
            String e = entry(i);
            Team t = sb.getTeam("ln" + i);
            if (t == null) {
                t = sb.registerNewTeam("ln" + i);
                t.addEntry(e);
            }
            t.prefix(Msg.c(content.get(i)));
            obj.getScore(e).setScore(n - i);
        }
        for (int i = n; i < lines; i++) {
            sb.resetScores(entry(i));
            Team t = sb.getTeam("ln" + i);
            if (t != null) t.unregister();
        }
        lines = n;
    }

    /** nama pemain -> tim. Kosongkan map untuk menghapus warna nametag. */
    public void nameTeams(Map<String, BWTeam> byName) {
        for (BWTeam t : BWTeam.values()) {
            Team st = sb.getTeam("bw_" + t.name());
            if (st == null) {
                st = sb.registerNewTeam("bw_" + t.name());
                st.color(t.text);
                st.prefix(Component.text(t.letter + " ", t.text));
            }
            for (String en : new HashSet<>(st.getEntries())) {
                if (byName.get(en) != t) st.removeEntry(en);
            }
        }
        for (Map.Entry<String, BWTeam> e : byName.entrySet()) {
            Team st = sb.getTeam("bw_" + e.getValue().name());
            if (st != null && !st.hasEntry(e.getKey())) st.addEntry(e.getKey());
        }
    }
}
