package id.bedwars;

/** Upgrade milik satu tim selama satu game. */
public class TeamUpgrades {
    public boolean sharp;   // Sharpened Swords
    public int armor;       // Reinforced Armor 0-4
    public int haste;       // Maniac Miner 0-2
    public int forge;       // Forge 0-4
    public boolean heal;    // Heal Pool
}
