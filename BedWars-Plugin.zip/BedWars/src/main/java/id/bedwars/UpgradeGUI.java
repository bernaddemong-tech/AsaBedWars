package id.bedwars;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/** Team upgrade (bayar Diamond, berlaku untuk seluruh tim). */
public class UpgradeGUI implements InventoryHolder {
    private static final int SHARP = 10, ARMOR = 11, HASTE = 12, FORGE = 13, HEAL = 14, BACK = 22;
    private static final int[] ARMOR_COST = {2, 4, 8, 16};
    private static final int[] HASTE_COST = {2, 4};
    private static final int[] FORGE_COST = {4, 8, 12, 16};
    private static final String[] FORGE_NAME = {"Iron Forge (+50%)", "Golden Forge (+100%)", "Emerald Forge (+Emerald)", "Molten Forge (+200%)"};

    private final Inventory inv;
    private final Game game;
    private final BWTeam team;

    private UpgradeGUI(Game game, BWTeam team) {
        this.game = game;
        this.team = team;
        inv = Bukkit.createInventory(this, 27, Msg.c("&b&lUpgrade Tim"));
        refresh();
    }

    public static void open(Player p, Game g) {
        BWTeam t = g.teamOf(p);
        if (t != null) p.openInventory(new UpgradeGUI(g, t).inv);
    }

    @Override
    public Inventory getInventory() { return inv; }

    private static String cost(int c) { return "&7Harga: &b" + c + " Diamond"; }

    private static ItemStack make(Material m, String name, String desc, String status) {
        return Items.named(m, 1, "&f" + name, List.of("&7" + desc, "", status));
    }

    private void refresh() {
        TeamUpgrades u = game.upgrades(team);
        inv.setItem(SHARP, make(Material.IRON_SWORD, "Sharpened Swords", "Pedang tim dapat Sharpness I",
                u.sharp ? "&aDimiliki" : cost(4)));
        inv.setItem(ARMOR, make(Material.IRON_CHESTPLATE, "Reinforced Armor (" + u.armor + "/4)", "Armor tim dapat Protection I-IV",
                u.armor >= 4 ? "&aMAKS" : cost(ARMOR_COST[u.armor])));
        inv.setItem(HASTE, make(Material.GOLDEN_PICKAXE, "Maniac Miner (" + u.haste + "/2)", "Haste I-II untuk tim",
                u.haste >= 2 ? "&aMAKS" : cost(HASTE_COST[u.haste])));
        inv.setItem(FORGE, make(Material.FURNACE, u.forge >= 4 ? "Forge (MAKS)" : FORGE_NAME[u.forge], "Generator base lebih cepat",
                u.forge >= 4 ? "&aMAKS" : cost(FORGE_COST[u.forge])));
        inv.setItem(HEAL, make(Material.BEACON, "Heal Pool", "Regenerasi di sekitar base",
                u.heal ? "&aDimiliki" : cost(1)));
        inv.setItem(BACK, Items.named(Material.ARROW, 1, "&eKembali ke Item Shop", null));
    }

    private boolean pay(Player p, int cost) {
        if (!p.getInventory().containsAtLeast(new ItemStack(Material.DIAMOND), cost)) {
            Msg.send(p, "&cKamu butuh " + cost + " Diamond.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return false;
        }
        p.getInventory().removeItem(new ItemStack(Material.DIAMOND, cost));
        return true;
    }

    public void click(Player p, int slot) {
        TeamUpgrades u = game.upgrades(team);
        String bought = null;
        switch (slot) {
            case SHARP -> { if (!u.sharp && pay(p, 4)) { u.sharp = true; bought = "Sharpened Swords"; } }
            case ARMOR -> { if (u.armor < 4 && pay(p, ARMOR_COST[u.armor])) { u.armor++; bought = "Reinforced Armor " + u.armor; } }
            case HASTE -> { if (u.haste < 2 && pay(p, HASTE_COST[u.haste])) { u.haste++; bought = "Maniac Miner " + u.haste; } }
            case FORGE -> { if (u.forge < 4 && pay(p, FORGE_COST[u.forge])) { u.forge++; bought = FORGE_NAME[u.forge - 1]; } }
            case HEAL -> { if (!u.heal && pay(p, 1)) { u.heal = true; bought = "Heal Pool"; } }
            case BACK -> {
                Bukkit.getScheduler().runTask(JavaPlugin.getPlugin(BedWarsPlugin.class), () -> ShopGUI.open(p));
                return;
            }
            default -> { return; }
        }
        if (bought != null) {
            game.onUpgrade(p, team, bought);
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
            refresh();
        }
    }
}
